#!/usr/bin/env python3
"""Retrospective evidence adjudication; never imports golden grader conclusions."""

import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import zipfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def adjudicate(case, inputs, output):
    if case == "bundled-audit-readiness":
        data = inputs["verification.json"]
        failures = [
            job["name"]
            for job in data["jobs"]
            if job["steps"]["Rebuild dist and verify parity"] == "failure"
        ]
        if not failures:
            return "unknown", "No failed parity evidence for this retrospective rule."
        valid = output == {
            "release_readiness": "not-ready",
            "reason": "bundle-parity-failed",
        }
        return (
            "valid-rejection" if valid else "invalid"
        ), "H1 is contradicted by failed rebuild parity in " + ", ".join(
            failures
        ) + "; dependency audit successes do not establish release readiness."
    current = inputs["current-run.json"]
    admissible = []
    rejected = []
    for name in ("observations.json", "restarted.json"):
        row = inputs[name]
        matching = (
            row["run_id"] == current["run_id"]
            and row["head"] == current["head"]
            and row["attempt"] == current["current_attempt"]
            and row["child_exit"] == 0
        )
        native = any(
            job["attempt"] == row["attempt"]
            and job["status"] == "completed"
            and job["conclusion"] == "success"
            for job in current["jobs"]
        )
        (admissible if matching and native else rejected).append(row["attempt"])
    if len(admissible) != 1 or 2 not in rejected:
        return (
            "unknown",
            "Evidence does not establish one current success and rejection of attempt 2.",
        )
    valid = output == {
        "accepted_attempt": admissible[0],
        "reason": "matching-successful-attempt",
    }
    return (
        ("valid-rejection" if valid else "invalid"),
        f"H2 is contradicted: attempt 2 is not current and its native job was cancelled; child_exit=0 is insufficient. Only attempt {admissible[0]} matches run, head, current_attempt and successful native conclusion.",
    )


def evaluate(source, output):
    output.mkdir()
    archive = source / "raw-evidence.zip"
    index = json.loads((source / "archive-index.json").read_text())
    expected_zip = next(row for row in index if row["path"] == archive.name)
    assert digest(archive.read_bytes()) == expected_zip["sha256"]
    z = zipfile.ZipFile(archive)
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
    protocol_raw = z.read("protocol.json")
    experiment_raw = z.read("experiment.json")
    for name, raw in [
        ("protocol.json", protocol_raw),
        ("experiment.json", experiment_raw),
    ]:
        assert raw == (source / name).read_bytes()
    protocol = json.loads(protocol_raw)
    experiment = json.loads(experiment_raw)
    assert (
        protocol["cases"] == experiment["cases"]
        and protocol["repetitions"] == experiment["repetitions"]
    )
    assert (
        protocol["timeout_seconds"] == experiment["timeout_seconds"]
        and protocol["total_seconds_limit"] == experiment["total_seconds_limit"]
    )
    expected = set(
        itertools.product(
            protocol["cases"], ["A", "B"], range(1, protocol["repetitions"] + 1)
        )
    )
    rows = {(r["case"], r["variant"], r["repetition"]): r for r in experiment["runs"]}
    assert len(rows) == len(experiment["runs"]) and set(rows) <= expected
    evidence = output / "raw"
    evidence.mkdir()
    results = []
    for case, variant, repetition in sorted(expected):
        key = (case, variant, repetition)
        row = rows.get(key)
        result = {
            "case": case,
            "hypothesis_id": "H1" if case == "bundled-audit-readiness" else "H2",
            "variant": variant,
            "repetition": repetition,
            "judgment": "unknown",
            "reason": "missing trial",
            "source_status": "missing",
            "seconds": None,
            "per_trial_budget_met": None,
            "internal_failed_commands": [],
        }
        results.append(result)
        if row is None:
            continue
        result.update(
            source_status=row["status"],
            seconds=row["seconds"],
            per_trial_budget_met=row["seconds"] <= protocol["timeout_seconds"],
        )
        trace = z.read(row["trace"])
        assert digest(trace) == row["trace_sha256"]
        result["run_ref"] = {
            "experiment_sha256": digest(experiment_raw),
            "case": case,
            "variant": variant,
            "repetition": repetition,
            "trace": row["trace"],
            "trace_sha256": digest(trace),
        }
        folder = evidence / Path(row["trace"]).parent
        folder.mkdir(parents=True)
        (folder / "trace.jsonl").write_bytes(trace)
        events = [json.loads(line) for line in trace.splitlines()]
        completed = [
            e["item"]
            for e in events
            if e.get("type") == "item.completed"
            and e.get("item", {}).get("type") == "command_execution"
        ]
        result["thread_ids"] = [
            e["thread_id"] for e in events if e.get("type") == "thread.started"
        ]
        result["internal_failed_commands"] = [
            c for c in completed if c["exit_code"] != 0
        ]
        result["agent_messages"] = [
            e["item"]["text"]
            for e in events
            if e.get("type") == "item.completed"
            and e.get("item", {}).get("type") == "agent_message"
        ]
        if row["status"] != "completed":
            result["reason"] = "Original trial not completed; retained in denominator."
            continue
        prefix = row["output"] + "/"
        members = {
            name[len(prefix) :]: z.read(name)
            for name in z.namelist()
            if name.startswith(prefix) and not name.endswith("/")
        }
        assert (
            digest(encoded({k: digest(v) for k, v in sorted(members.items())}))
            == row["output_sha256"]
        )
        case_raw = z.read("cases/" + case + "/case.json")
        assert digest(case_raw) == protocol["case_sha256"][case]
        definition = json.loads(case_raw)
        # Deliberately never access definition['expected'], comparison.json, or any grader.
        originals = {
            name: value.encode() if isinstance(value, str) else encoded(value)
            for name, value in definition["files"].items()
        }
        originals["input.md"] = z.read("cases/" + case + "/input.md")
        assert (
            digest(encoded({k: digest(v) for k, v in originals.items()}))
            == protocol["input_sha256"][case]
            == row["input_sha256"]
        )
        assert all(members.get(k) == v for k, v in originals.items())
        result["originals"] = [
            {"path": k, "sha256": digest(v), "bytes": len(v)}
            for k, v in originals.items()
        ]
        for name, raw in members.items():
            target = folder / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        inputs = {k: json.loads(v) for k, v in originals.items() if k.endswith(".json")}
        required = (
            ["verification.json"]
            if case == "bundled-audit-readiness"
            else ["current-run.json", "observations.json", "restarted.json"]
        )
        reads = {
            name: [
                c["id"]
                for c in completed
                if c["exit_code"] == 0
                and originals[name].decode().strip() in c.get("aggregated_output", "")
            ]
            for name in required
        }
        result["trace_source_reads"] = reads
        if not all(reads.values()) or not any(
            e.get("type") == "turn.completed" for e in events
        ):
            result["reason"] = (
                "Source read or completed turn not evidenced in retained trace."
            )
            continue
        name = (
            "assessment.json" if case == "bundled-audit-readiness" else "selection.json"
        )
        result["output"] = {
            "path": prefix + name,
            "sha256": digest(members[name]),
            "value": json.loads(members[name]),
        }
        result["judgment"], result["reason"] = adjudicate(
            case, inputs, result["output"]["value"]
        )
        if not result["per_trial_budget_met"]:
            result["judgment"] = "unknown"
            result["reason"] += " Trial exceeded the original time budget."
    groups = {}
    for variant in ["A", "B"]:
        selected = [r for r in results if r["variant"] == variant]
        groups[variant] = {
            "planned_judgments": len(selected),
            "unique_hypotheses": len({r["hypothesis_id"] for r in selected}),
            "judgments": dict(Counter(r["judgment"] for r in selected)),
            "valid_judgments_within_original_per_trial_budget": sum(
                r["judgment"].startswith("valid-") for r in selected
            ),
            "observed_machine_seconds_sum": sum(r["seconds"] or 0 for r in selected),
            "failed_internal_commands": sum(
                len(r["internal_failed_commands"]) for r in selected
            ),
        }
    controls = []
    for case in protocol["cases"]:
        sample = next(r for r in results if r["case"] == case)
        folder = evidence / Path(sample["run_ref"]["trace"]).parent
        inputs = {p.name: json.loads(p.read_text()) for p in folder.glob("*.json")}
        wrong = (
            {"release_readiness": "ready", "reason": "checks-complete"}
            if case == protocol["cases"][0]
            else {"accepted_attempt": 2, "reason": "matching-successful-attempt"}
        )
        verdict, reason = adjudicate(case, inputs, wrong)
        assert verdict == "invalid"
        controls.append(
            {
                "case": case,
                "synthetic_wrong_output": wrong,
                "judgment": verdict,
                "reason": reason,
                "scope": "new reducer negative, not original model trial",
            }
        )
    report = {
        "schema": "retrospective-hypothesis-adjudication/v1",
        "archive_sha256": expected_zip["sha256"],
        "protocol_sha256": digest(protocol_raw),
        "experiment_sha256": digest(experiment_raw),
        "unique_hypotheses": 2,
        "planned_judgments": len(expected),
        "original_budget": {
            "per_trial_seconds": protocol["timeout_seconds"],
            "total_wall_seconds_limit": protocol["total_seconds_limit"],
        },
        "groups": groups,
        "full_collection_wall_seconds": None,
        "full_collection_wall_reason": "Only individual subprocess durations retained; setup/gaps/termination overhead are not a recorded complete wall interval.",
        "valid_judgments_within_total_wall_budget": None,
        "total_budget_reason": "Original collector enforces remaining-time limits, but complete wall interval was not independently recorded.",
        "human_active_seconds": None,
        "resume_decision_changes": None,
        "resume_reason": "No interrupted/resumed reviewer trial in this cohort; underlying attempt2/3 source example is not a resumed reviewer session.",
        "results": results,
        "negative_controls": controls,
    }
    save(output / "adjudications.json", report)
    print(
        json.dumps(
            {
                k: report[k]
                for k in [
                    "unique_hypotheses",
                    "planned_judgments",
                    "groups",
                    "valid_judgments_within_total_wall_budget",
                ]
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    evaluate(args.source, args.output)
