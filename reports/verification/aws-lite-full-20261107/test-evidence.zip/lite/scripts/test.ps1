$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '..')
try {
    python3 -m unittest
    exit $LASTEXITCODE
}
finally {
    Pop-Location
}
