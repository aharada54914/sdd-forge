"""Summarize S3 notification JSON locally using the standard library."""

import json
import sys
from urllib.parse import unquote_plus


def _mapping(value, location):
    if not isinstance(value, dict):
        raise ValueError(f"{location} must be an object")
    return value


def _text(value, location):
    if not isinstance(value, str) or not value:
        raise ValueError(f"{location} must be a nonempty string")
    return value


def summarize(event):
    """Return ordered bucket/key summaries, or raise ValueError on bad input."""
    event = _mapping(event, "event")
    records = event.get("Records")
    if not isinstance(records, list):
        raise ValueError("Records must be a list")
    result = []
    for index, record in enumerate(records):
        location = f"Records[{index}]"
        record = _mapping(record, location)
        s3 = _mapping(record.get("s3"), f"{location}.s3")
        bucket = _mapping(s3.get("bucket"), f"{location}.s3.bucket")
        obj = _mapping(s3.get("object"), f"{location}.s3.object")
        name = _text(bucket.get("name"), f"{location}.s3.bucket.name")
        key = _text(obj.get("key"), f"{location}.s3.object.key")
        result.append({"bucket": name, "key": unquote_plus(key)})
    return result


def _reject_constant(value):
    raise ValueError(f"invalid JSON constant: {value}")


def main():
    """Read one JSON document and emit either a summary or a concise error."""
    try:
        result = summarize(json.load(sys.stdin, parse_constant=_reject_constant))
    except ValueError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2
    json.dump(result, sys.stdout)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
