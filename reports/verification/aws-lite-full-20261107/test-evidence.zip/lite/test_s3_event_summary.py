"""Behavioral coverage for the offline summarizer and its CLI."""

import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

from s3_event_summary import summarize


def record(bucket="photos", key="folder/a+b%2Bc%20d.txt"):
    return {"s3": {"bucket": {"name": bucket}, "object": {"key": key}}}


class SummaryTests(unittest.TestCase):
    def test_single_and_multiple_records_decode_in_order_without_mutation(self):
        event = {"Records": [record(), record("second", "%E6%97%A5%2Ffile")]}
        original = copy.deepcopy(event)
        self.assertEqual(summarize({"Records": [record()]}), [
            {"bucket": "photos", "key": "folder/a b+c d.txt"}])
        result = summarize(event)
        self.assertEqual(result, [
            {"bucket": "photos", "key": "folder/a b+c d.txt"},
            {"bucket": "second", "key": "日/file"}])
        self.assertEqual(event, original)
        result[0]["bucket"] = "changed"
        self.assertEqual(event, original)

    def test_empty_records(self):
        self.assertEqual(summarize({"Records": []}), [])

    def test_no_extra_normalization(self):
        self.assertEqual(summarize({"Records": [record(" ", "+%ZZ")]}),
                         [{"bucket": " ", "key": " %ZZ"}])

    def test_invalid_event_and_records(self):
        for event in (None, [], "event", 1, True, {}, {"Records": None},
                      {"Records": {}}, {"Records": ()}, {"Records": ""}):
            with self.subTest(event=event), self.assertRaises(ValueError):
                summarize(event)

    def test_missing_and_malformed_nested_containers(self):
        paths = [(), ("s3",), ("s3", "bucket"), ("s3", "object")]
        for path in paths:
            for bad in (None, [], "text", 3, True):
                item = record()
                if not path:
                    item = bad
                else:
                    parent = item
                    for key in path[:-1]:
                        parent = parent[key]
                    parent[path[-1]] = bad
                with self.subTest(path=path, bad=bad), self.assertRaises(ValueError):
                    summarize({"Records": [item]})
        for path in (("s3",), ("s3", "bucket"), ("s3", "object")):
            item = record()
            parent = item
            for key in path[:-1]:
                parent = parent[key]
            del parent[path[-1]]
            with self.subTest(missing=path), self.assertRaises(ValueError):
                summarize({"Records": [item]})

    def test_missing_empty_and_nonstring_leaves(self):
        for container, leaf in (("bucket", "name"), ("object", "key")):
            for bad in (None, "", 0, False, [], {}):
                item = record()
                item["s3"][container][leaf] = bad
                with self.subTest(container=container, bad=bad), self.assertRaises(ValueError):
                    summarize({"Records": [item]})
            item = record()
            del item["s3"][container][leaf]
            with self.subTest(missing=leaf), self.assertRaises(ValueError):
                summarize({"Records": [item]})

    def test_invalid_later_record_fails_without_mutation(self):
        event = {"Records": [record(), record(key="")]}
        original = copy.deepcopy(event)
        with self.assertRaises(ValueError):
            summarize(event)
        self.assertEqual(event, original)


class CliTests(unittest.TestCase):
    def run_cli(self, source):
        return subprocess.run(
            [sys.executable, str(Path(__file__).with_name("s3_event_summary.py"))],
            input=source, text=True, capture_output=True, timeout=5)

    def test_success_and_empty(self):
        for event, expected in (
                ({"Records": [record()]}, [{"bucket": "photos", "key": "folder/a b+c d.txt"}]),
                ({"Records": []}, [])):
            with self.subTest(event=event):
                process = self.run_cli(json.dumps(event))
                self.assertEqual(process.returncode, 0, process.stderr)
                self.assertEqual(process.stderr, "")
                self.assertEqual(json.loads(process.stdout), expected)

    def test_invalid_json_and_events(self):
        for source in ("", "{", "{} {}", "null", "{}", '{"Records":[{}]}'):
            with self.subTest(source=source):
                process = self.run_cli(source)
                self.assertEqual(process.returncode, 2)
                self.assertEqual(process.stdout, "")
                self.assertTrue(process.stderr.startswith("error: "))
                self.assertEqual(len(process.stderr.splitlines()), 1)
                self.assertNotIn("Traceback", process.stderr)

    def test_non_json_constants_are_rejected_even_in_unused_fields(self):
        for literal in ("NaN", "Infinity", "-Infinity"):
            for extra in (literal, "[" + literal + "]", '{"nested":' + literal + '}'):
                source = '{"Records":[],"extra":' + extra + '}'
                with self.subTest(source=source):
                    process = self.run_cli(source)
                    self.assertEqual(process.returncode, 2)
                    self.assertEqual(process.stdout, "")
                    self.assertTrue(process.stderr.startswith("error: "))
                    self.assertEqual(len(process.stderr.splitlines()), 1)
                    self.assertNotIn("Traceback", process.stderr)

    def test_constant_names_inside_json_strings_remain_valid(self):
        for text in ("NaN", "Infinity", "-Infinity"):
            with self.subTest(text=text):
                process = self.run_cli(json.dumps({"Records": [record(key=text)], "extra": text}))
                self.assertEqual(process.returncode, 0, process.stderr)
                self.assertEqual(process.stderr, "")
                self.assertEqual(json.loads(process.stdout), [{"bucket": "photos", "key": text}])

    def test_import_has_no_cli_side_effect(self):
        process = subprocess.run([sys.executable, "-c", "import s3_event_summary"],
                                 input="bad json", text=True, capture_output=True, timeout=5)
        self.assertEqual((process.returncode, process.stdout, process.stderr), (0, "", ""))


if __name__ == "__main__":
    unittest.main()
