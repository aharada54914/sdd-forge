# Diagnosis Report: s3-event-summary-T-001-json-constants

- **Symptom (user's words)**: External acceptance actually ran the current CLI with {"Records":[],"extra":NaN} and Infinity/-Infinity. All exited 0, violating the accepted invalid-JSON exit-2 requirement.
- **Source**: reports/bootstrap/external-json-acceptance-finding.json; user references GitHub issue #740 (no remote access performed).

## Phase 1 — Feedback loop

Command run before repair:

```sh
python3 -m unittest test_s3_event_summary.CliTests.test_non_json_constants_are_rejected_even_in_unused_fields
```

Actual red output: `Ran 1 test`; `FAILED (failures=9)`; each subcase reports `AssertionError: 0 != 2`. Complete output is in reports/implementation/s3-event-summary/T-001/correction-2/red.json.
Loop properties: red-capable, deterministic, fast, agent-runnable.

## Phase 2 — Reproduce + minimize

Confirmed the original symptom with all three literal constants and empty Records. Minimized parser input is `NaN`; the CLI needs `{"Records":[],"extra":NaN}` to pass structural validation and expose acceptance of the invalid syntax. Nested array/object cases guard against a top-level-only repair.

## Phase 3 — Hypotheses (ranked, falsifiable)

1. Default json decoding accepts non-JSON constants; replacing parse_constant with a rejecting hook will raise ValueError before summarization. Confirmed by parser probe and green regression.
2. Summarizer alone ignores invalid extra values; if decoding were strict, parser-only input would already fail. Refuted as primary cause: parser-only input produces float.
3. CLI masks parser errors as success; if so a rejecting hook would still exit 0. Refuted: the existing ValueError handler returns 2 after the hook raises.

Ranking was communicated before probing.

## Phase 4 — Instrumentation

Small parser-only probe changed only parse_constant: defaults returned float for every literal, rejecting hook raised ValueError for each. Evidence: reports/implementation/s3-event-summary/T-001/correction-2/parser-probe.json. No temporary production instrumentation added.

## Phase 5 — Root cause + fix

Default Python json.load accepts NaN and infinities. The CLI now supplies parse_constant=_reject_constant; the existing error handler emits one stderr line and exits 2. Regression written before repair at the subprocess seam covers the exact failure plus nested unused fields. Quoted constant names remain valid strings. All previous tests retained.

## Technical gate finding

The prior independent report reports/quality-gate/T-001.md and execution JSON remain unchanged. The installed runner requires a regular paired scripts/test.sh and scripts/test.ps1; it does not discover the prose unittest command in AGENTS.md. Added that documented pair, running the same python3 -m unittest suite and propagating exit status. No discovery or guard edits.

## Handoff

Lite correction to already human-approved T-001 under unchanged REQ-004 and REQ-005; user explicitly authorized technical correction. No new approval or specification decision needed. Fresh independent Lite gate pending; only it can decide Done.
