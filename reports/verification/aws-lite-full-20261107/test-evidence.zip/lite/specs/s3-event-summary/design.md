# Design (lite): s3-event-summary

## Approach

Use a single Python module with a pure `summarize(event)` function and a CLI entry point guarded by `if __name__ == '__main__'`. The repository has no existing application code or module conventions beyond standard-library Python and unittest. Validate the payload structure explicitly, raising `ValueError` rather than leaking indexing or type exceptions.

## New files

- `s3_event_summary.py` — validation, transformation, and stdin/stdout CLI.
- `test_s3_event_summary.py` — discoverable unittest coverage for the function and CLI.

## Data and interface

- Input: dictionary with list-valued `Records`; each record is a dictionary whose `s3`, `bucket`, and `object` containers are dictionaries with nonempty string `name` and `key` leaves respectively.
- Output: one `{'bucket': name, 'key': unquote_plus(key)}` dictionary per record, preserving order. Validate raw key nonemptiness before decoding; no additional key normalization or URL validation is required.
- Build a fresh result without mutating input. An invalid record causes the whole call to raise `ValueError`, with no partial result returned.
- CLI uses `json.load(sys.stdin)` and serializes the successful result to stdout. Catch JSON parse and event validation failures, write a short error to stderr without a traceback, and return 2. Importing the module does not run the CLI.

## Test approach

- Cover one and multiple records, order, plus-to-space and percent decoding, empty Records, and input preservation.
- Table-driven invalid cases cover top-level type, Records presence/type, malformed records and intermediate containers, and absent/empty/non-string leaves.
- Exercise the CLI through the Python executable with captured stdin/stdout/stderr: valid payload, empty Records, invalid JSON, and invalid event; assert exit codes and parse successful stdout as JSON.
- Run `python3 -m unittest` from the repository root; no dependencies or external services.

## Full workflow migration

If scope or risk requires full SDD, stop the lite flow and use `sdd-bootstrap-interviewer` to establish full specifications and required reviews before further implementation.
