# Tasks (lite): s3-event-summary

## T-001 Implement and test the offline S3 event summary utility
Approval: Approved
Status: Done

### Scope

- Create `s3_event_summary.py` and `test_s3_event_summary.py` according to requirements.md and design.md.
- Implement the pure summarizer, structural validation, key decoding, and JSON stdin/stdout CLI using only the Python standard library.
- Add discoverable unittest coverage for successful transformations, validation errors, and CLI behavior.

### Done When

- `summarize(event)` returns ordered bucket/key dictionaries, decodes keys with `unquote_plus`, returns `[]` for empty Records, and preserves the input.
- Every invalid input category in REQ-003 raises `ValueError`, including malformed nested containers and absent/empty/non-string leaves.
- CLI success produces valid JSON and exit 0; invalid JSON and invalid events produce concise stderr errors and exit 2 without a traceback or success output.
- `python3 -m unittest` passes with function and subprocess CLI cases described in design.md.
- Implementation uses no third-party packages or external services and has no persistence or infrastructure operations.
- The applicable independent quality gate verifies the implementation before any Done decision.

### Blockers

- None.
