# Requirements (lite): s3-event-summary

- **Source**: `requirements-source.md`.
- **Purpose**: Transform S3 notification payloads locally into bucket/key summaries using only the Python standard library.

## Requirements

- REQ-001: `s3_event_summary.py` exposes `summarize(event)`, accepting a dictionary and returning a list of dictionaries containing `bucket` and `key` for each record, in input order. Read names from `record['s3']['bucket']['name']` and keys from `record['s3']['object']['key']`.
- REQ-002: Decode each object key using `urllib.parse.unquote_plus`. Empty `Records` returns an empty list.
- REQ-003: Raise `ValueError` for a non-dictionary event, missing or non-list `Records`, a malformed record, or an absent, empty, or non-string bucket name or object key.
- REQ-004: The CLI reads one JSON document from stdin, writes the summary as JSON to stdout, and exits 0. Invalid JSON or an invalid event produces a concise error on stderr and exits 2.
- REQ-005: Include standard-library `unittest` coverage; validate with `python3 -m unittest`.

## Out of scope

- credentials

## Other excluded scope

- SDKs, network requests, deployment, infrastructure, persistence, and external side effects.

## Open Questions

- None.
