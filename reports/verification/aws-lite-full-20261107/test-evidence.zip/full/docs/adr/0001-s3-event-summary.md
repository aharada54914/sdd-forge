# ADR 0001: Offline summary module

Status: Proposed
Date: 2026-11-07

## Context
REQ-001–005 require a local Python transformation and stdin/stdout CLI, without external side effects.

## Decision
Use one standard-library module with a pure summarize function, explicit nested validation, unquote_plus decoding, and a main-guarded CLI adapter. Keep process stream/error handling separate from the callable function.

## Consequences
No SDK, network, storage or deployment is needed. The complete document and result occupy local memory. Unit tests cover transformation; subprocess tests cover the actual CLI. No hosted-service capacity guarantees are introduced.
