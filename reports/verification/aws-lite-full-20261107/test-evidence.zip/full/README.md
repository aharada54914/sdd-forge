# AWS S3 notification local utility

Offline workflow verification project. No deployment, credentials, SDK, or live cloud operations.

## CLI

From this directory, with Python 3:

```sh
printf '%s\n' '{"Records":[{"s3":{"bucket":{"name":"example-bucket"},"object":{"key":"folder/a+b%2Bc"}}}]}' | python3 s3_event_summary.py
```

Output:

```json
[{"bucket": "example-bucket", "key": "folder/a b+c"}]
```

The CLI reads one JSON document from stdin. Success writes JSON to stdout,
leaves stderr empty, and exits 0. Empty `Records` produces `[]`.
Invalid JSON or event shapes produce a concise, payload-free stderr error,
no stdout result, and exit 2. Unquoted `NaN`, `Infinity`, and `-Infinity`
are invalid anywhere in JSON; quoted strings are valid strings.

## Python callable

```python
from s3_event_summary import summarize

result = summarize({"Records": [
    {"s3": {"bucket": {"name": "example-bucket"},
            "object": {"key": "folder/a+b%2Bc"}}}
]})
assert result == [{"bucket": "example-bucket", "key": "folder/a b+c"}]
```

`summarize(event)` requires a dictionary with a `Records` list. Each record,
`s3`, `bucket`, and `object` must be dictionaries; `name` and `key` must be
nonempty strings. Invalid input raises `ValueError`, even if earlier records
were valid. Input is not mutated. Extra fields are ignored, order is preserved,
and keys are decoded once with `urllib.parse.unquote_plus`. Standard decoder
behavior applies to Unicode and malformed percent escapes. Names and decoded
keys are data, never filesystem paths or commands.

## Validation

```sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest
```

Tests use only synthetic data, direct calls, and real local subprocesses.
The module uses only the standard library, performs no network or storage
operations, and does not execute the CLI on import. The full document and
result reside in memory; no input-size guarantee is provided.
