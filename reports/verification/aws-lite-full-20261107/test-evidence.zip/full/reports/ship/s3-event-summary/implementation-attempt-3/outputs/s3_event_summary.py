"""Offline S3 notification summaries using only the Python standard library."""
import json
import sys
from urllib.parse import unquote_plus


def summarize(event):
    """Return ordered bucket/decoded-key pairs; invalid shapes raise ValueError.

    Required strings are checked before decoding. Unrelated fields are ignored,
    and the input is never modified, including when a later record is invalid.
    """
    if not isinstance(event, dict) or not isinstance(event.get('Records'), list):
        raise ValueError('event must contain a Records list')
    result = []
    for record in event['Records']:
        if not isinstance(record, dict):
            raise ValueError('record must be a dictionary')
        s3 = record.get('s3')
        if not isinstance(s3, dict):
            raise ValueError('s3 must be a dictionary')
        bucket = s3.get('bucket')
        obj = s3.get('object')
        if not isinstance(bucket, dict) or not isinstance(obj, dict):
            raise ValueError('bucket and object must be dictionaries')
        name = bucket.get('name')
        key = obj.get('key')
        if not isinstance(name, str) or not name:
            raise ValueError('bucket name must be a nonempty string')
        if not isinstance(key, str) or not key:
            raise ValueError('object key must be a nonempty string')
        result.append({'bucket': name, 'key': unquote_plus(key)})
    return result


def _reject_constant(value):
    """Disallow Python's non-JSON numeric extensions, even in unused fields."""
    raise ValueError('nonstandard JSON constant')


def main():
    """Read one JSON document and return the CLI exit status."""
    try:
        event = json.load(sys.stdin, parse_constant=_reject_constant)
        result = summarize(event)
    except ValueError:
        print('error: invalid JSON or S3 event', file=sys.stderr)
        return 2
    print(json.dumps(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())
