# UX Specification: S3 event summary

## Scope and User Journeys

Local CLI caller runs python3 s3_event_summary.py from the repository root with stdin JSON; gets JSON or concise stderr. REQ-004 / AC-005, AC-006. Import users call summarize directly. No graphical journey.

## Target Views

N/A — no change: no GUI views.

## Component States

Empty Records: []; valid: JSON list/stdout/status 0; invalid: concise stderr/status 2/no result stdout. No loading UI. REQ-003/004; AC-003/005/006.

## Interaction Sequence

Read stdin → parse JSON → validate and transform → emit JSON or error. Correct the supplied input and rerun on validation failure.

## Wireframe Attachments

No mockup provided — optional visualization skipped

None — manual visual refinement skipped

## Navigation Map

Single script entry; no routes, back navigation or guarded views.

## Accessibility

Plain text errors and machine-readable stdout; graphical WCAG concepts are N/A for this CLI.

## Responsive Behavior

N/A — no change: no responsive interface.

## Design Tokens

ds_profile: none

No visual tokens.

## Open Questions

None.
