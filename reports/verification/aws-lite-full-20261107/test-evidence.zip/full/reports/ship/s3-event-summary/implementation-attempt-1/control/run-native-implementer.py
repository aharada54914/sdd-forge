import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path.cwd()
BASE = ROOT / 'reports/ship/s3-event-summary/implementation-attempt-1'
CONTROL = BASE / 'control'
OUTPUTS = BASE / 'outputs'
SNAPSHOT = BASE / 'snapshot'
INST = Path('/workspace/.tools/sdd-forge-dev/codex-verify/plugins/cache/sdd-plugins')
SCRIPT = INST / 'sdd-review-loop/1.23.1/scripts/launch-codex-review.py'
spec = importlib.util.spec_from_file_location('native_transport', SCRIPT)
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
save = lambda n, v: (CONTROL / n).write_text(json.dumps(v, indent=2) + '\n')
cli = Path(shutil.which('codex')).resolve()
profile = 'sdd_task_implementation'
permissions = {'network': {'enabled': False}, 'filesystem': {
    ':minimal': 'read', str(SNAPSHOT): 'read', str(CONTROL): 'read',
    str(OUTPUTS): 'write', str(cli): 'read'}}
command = [str(cli), '--model', 'gpt-6-astra', '-c', 'model_reasoning_effort="medium"',
    'app-server', '--stdio', '--strict-config',
    '-c', 'permissions.' + profile + '=' + '{network={enabled=false},filesystem={' +
    ','.join(json.dumps(k) + '=' + json.dumps(v) for k, v in permissions['filesystem'].items()) + '}}',
    '-c', 'default_permissions=' + json.dumps(profile),
    '-c', 'web_search="disabled"', '-c', 'project_doc_max_bytes=0',
    '-c', 'features.plugins=false', '-c', 'features.apps=false',
    '-c', 'features.multi_agent=false']
# Parent guards remain enabled. No setting disables hooks.
save('native-command.json', command)
rpc = transport.Rpc(command, OUTPUTS, CONTROL, 1200)
try:
    transport.initialize(rpc)
    config = rpc.request('config/read', {'includeLayers': False}, record=False)['config']
    save('model-control-observation.json', {k: config.get(k) for k in ('model', 'model_reasoning_effort')})
    assert config['model'] == 'gpt-6-astra'
    assert config['model_reasoning_effort'] == 'medium'
    allocation = rpc.request('thread/start', {'cwd': str(OUTPUTS), 'model': 'gpt-6-astra',
        'permissions': profile, 'approvalPolicy': 'never', 'selectedCapabilityRoots': [],
        'baseInstructions': 'Implement exactly one approved local utility task. Read only the named immutable snapshot and task manifest. Write only the task output roots. Do not alter shared status, approval, specs, installed tools, or live repository files. No network, credentials, AWS, commits, publication, or delegation.',
        'config': {'project_doc_max_bytes': 0, 'model_reasoning_effort': 'medium'}})
    save('idle-allocation.json', allocation)
    thread = allocation['thread']
    ident = thread['id']
    assert not thread['turns'] and thread['status']['type'] == 'idle'
    assert allocation['activePermissionProfile']['id'] == profile
    source = ROOT / 'reports/ship/s3-event-summary/model-admission'
    selection = json.loads((source / 'selection.json').read_text())
    cost = json.loads((source / 'model-cost-evidence.json').read_text())
    names = ['AGENTS.md', 'README.md', 'requirements-source.md',
        'reports/bootstrap/user-approval.json', 'contracts/s3-event-summary.md',
        'docs/adr/0001-s3-event-summary.md']
    names += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'specs/s3-event-summary').glob('*.md'))]
    names += [str(p.relative_to(ROOT)) for p in sorted(CONTROL.glob('*.md'))]
    names += [str((source / n).relative_to(ROOT)) for n in
        ('selection.json', 'candidates.json', 'model-cost-evidence.json')]
    allowed = ['s3_event_summary.py', 'test_s3_event_summary.py', 'README.md',
        'reports/implementation/s3-event-summary/T-001.md',
        'specs/s3-event-summary/verification/T-001/']
    manifest = dict(schema='task-input-manifest/v1', task_id='T-001', run_id=ident,
        session_id=ident, agent_instance_id=ident, model_tier=selection['canonical_tier'],
        provider='openai', model=selection['model'],
        estimated_cost_per_attempt_usd=selection['estimated_cost_per_attempt_usd'],
        cost_estimate_source=cost['cost_estimate_source'], cost_estimate_timestamp=cost['observed_at'],
        isolation_mode='fresh-agent', fallback_reason='', handoff_reload_evidence_hash='',
        allowed_inputs=[dict(path=n, sha256=sha(ROOT / n)) for n in names], allowed_outputs=allowed)
    save('task-input-manifest.json', manifest)
    manifest_path = CONTROL / 'task-input-manifest.json'
    scripts = INST / 'sdd-implementation/1.23.1/scripts'
    def checked(name, args):
        result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
        (CONTROL / name).write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
    checked('snapshot-validation.txt', ['bash', str(scripts / 'prepare-task-snapshot.sh'),
        '--manifest', str(manifest_path), '--repo-root', str(ROOT), '--snapshot-root', str(SNAPSHOT)])
    checked('manifest-validation.txt', ['bash', str(scripts / 'validate-task-input-manifest.sh'),
        '--manifest', str(manifest_path), '--snapshot-root', str(SNAPSHOT), '--expected-task', 'T-001'])
    checked('batch-validation.txt', ['bash', str(scripts / 'validate-task-input-manifest.sh'),
        '--batch', str(manifest_path)])
    probe = rpc.request('command/exec', {'command': ['/bin/sh', '-c',
        'touch .admission-probe && rm .admission-probe'], 'cwd': str(OUTPUTS),
        'permissionProfile': profile, 'timeoutMs': 5000})
    save('output-root-probe.json', probe)
    assert probe['exitCode'] == 0
    denial = rpc.request('command/exec', {'command': ['/bin/sh', '-c',
        'touch /tmp/s3-summary-outside-probe'], 'cwd': str(OUTPUTS),
        'permissionProfile': profile, 'timeoutMs': 5000})
    save('outside-write-probe.json', denial)
    assert denial['exitCode'] != 0
    task = ROOT / 'specs/s3-event-summary/tasks.md'
    text = task.read_text()
    assert 'Approval: Approved' in text and 'Status: Planned' in text
    task.write_text(text.replace('Status: Planned', 'Status: In Progress', 1))
    brief = f'''Manifest: {manifest_path}; SHA-256: {sha(manifest_path)}.
Immutable snapshot root: {SNAPSHOT}. Writable output root: {OUTPUTS}.
Follow the snapshot task and supplied implementation policies. Read the manifest, then only its listed snapshot inputs. The snapshot Approved/Planned state is the admitted input; parent now owns live In Progress state. Do not write tasks or traceability.
Your actual native run/session/agent identity is {ident}; model gpt-6-astra, effort medium, native flags verified before this turn. Scratch Root in your report: {OUTPUTS}.
Implement the module and tests acceptance-first, using meaningful direct tests and real subprocess CLI tests. Unquoted NaN/Infinity/-Infinity must be rejected even in unused JSON fields; quoted strings stay valid. Test complete invalid nested shapes, whole-call error, decoding, nonmutation, stream/status handling and no import side effects. Use only stdlib, synthetic input, no live AWS or credentials.
Run python3 -m unittest from the output root, save real output in specs/s3-event-summary/verification/T-001/unittest.txt. Avoid bytecode/intermediates outside declared outputs (PYTHONDONTWRITEBYTECODE=1). Tests before/with implementation; save actual initial failing acceptance output if produced. No commits.
Write reports/implementation/s3-event-summary/T-001.md from the provided template. Use actual hashes in Outputs for every produced source/test/README/evidence file. Do not include the report itself in its hash table. Cite exactly: Input manifest: `{manifest_path.relative_to(ROOT)}`, SHA-256 `{sha(manifest_path)}`. Record Isolation Mode fresh-agent, fallback fields None, actual identity above, cost source truthfully as planning estimate, Model and Effort. Complete your own scoped inspection and report evidence. No visual verification applies to CLI-only work.
Return only file-backed output paths and completion/blocker summary. Parent validates/adopts and alone writes live status. No independent evaluator work in this context.'''
    (CONTROL / 'launch-brief.txt').write_text(brief)
    started = rpc.request('turn/start', {'threadId': ident, 'permissions': profile,
        'approvalPolicy': 'never', 'input': [{'type': 'text', 'text_elements': [], 'text': brief}]})
    turn = started['turn']['id']
    messages = []
    while True:
        event = rpc.events.pop(0) if rpc.events else rpc.receive()
        params = event.get('params', {})
        if event.get('method') == 'item/completed' and params['item'].get('type') == 'agentMessage':
            messages.append(params['item']['text'])
        if event.get('method') == 'turn/completed':
            assert params['turn']['id'] == turn and params['turn']['status'] == 'completed'
            break
    (CONTROL / 'implementer-result.txt').write_text('\n'.join(messages) + '\n')
    produced = []
    for p in OUTPUTS.rglob('*'):
        if p.is_file():
            rel = str(p.relative_to(OUTPUTS))
            assert any(rel == n or (n.endswith('/') and rel.startswith(n)) for n in allowed), rel
            produced.append(dict(path=rel, sha256=sha(p)))
    save('produced-files.json', produced)
    print('IMPLEMENTATION_OUTPUT_CANDIDATE ' + str(OUTPUTS), flush=True)
finally:
    rpc.close()
