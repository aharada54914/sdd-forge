"""Synthetic acceptance tests TEST-001–007; no services or third parties."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

from s3_event_summary import summarize

ROOT = Path(__file__).resolve().parent


def record(bucket='sample-bucket', key='folder/a+b%2Bc'):
    return {'s3': {'bucket': {'name': bucket}, 'object': {'key': key}}}


def invalid_events():
    for value in (None, [], 'event', 3, True):
        yield 'event ' + repr(value), value
    yield 'missing Records', {}
    for value in (None, {}, 'records', 3, True, ()):
        yield 'Records ' + repr(value), {'Records': value}
    for value in (None, [], 'record', 3, True):
        yield 'record ' + repr(value), {'Records': [value]}
    for path in (('s3',), ('s3', 'bucket'), ('s3', 'object'),
                 ('s3', 'bucket', 'name'), ('s3', 'object', 'key')):
        values = (None, [], 'wrong-container', 3, True) if len(path) < 3 else (None, 3, [], {}, '', True)
        for missing, value in [(True, None)] + [(False, v) for v in values]:
            item = record()
            parent = item
            for part in path[:-1]:
                parent = parent[part]
            if missing:
                del parent[path[-1]]
            else:
                parent[path[-1]] = value
            yield repr((path, missing, value)), {'Records': [item]}


class SummaryTests(unittest.TestCase):
    def test_001_order_exact_fields_and_nonmutation(self):
        event = {'Records': [record('B+%20', 'first'), record('a', 'second')], 'extra': [1]}
        event['Records'][0]['s3']['object']['size'] = 10
        before = copy.deepcopy(event)
        result = summarize(event)
        self.assertEqual(result, [{'bucket': 'B+%20', 'key': 'first'}, {'bucket': 'a', 'key': 'second'}])
        self.assertEqual(event, before)
        self.assertIsNot(result, event['Records'])
        self.assertIsNot(result[0], result[1])
        result[0]['bucket'] = 'changed'
        self.assertEqual(event, before)
        self.assertEqual(summarize(event)[0]['bucket'], 'B+%20')

    def test_002_decoding_once_and_raw_validation(self):
        cases = [('a+b%20c%2Bd', 'a b c+d'), ('%252B', '%2B'),
                 ('%E2%98%83/雪', '☃/雪'), ('bad%ZZ%', 'bad%ZZ%'),
                 ('%FF', '\ufffd'), ('+', ' '), ('%00', '\x00'),
                 ('../a;$(echo+x)', '../a;$(echo x)')]
        for raw, expected in cases:
            with self.subTest(raw=raw):
                self.assertEqual(summarize({'Records': [record(' ', raw)]}),
                                 [{'bucket': ' ', 'key': expected}])

    def test_003_empty(self):
        event = {'Records': []}
        self.assertEqual(summarize(event), [])
        self.assertIsNot(summarize(event), event['Records'])

    def test_004_invalid_shapes_and_nonmutation(self):
        for label, event in invalid_events():
            with self.subTest(case=label):
                before = copy.deepcopy(event)
                with self.assertRaises(ValueError):
                    summarize(event)
                self.assertEqual(event, before)

    def test_004_later_invalid_fails_whole_call(self):
        for label, invalid in invalid_events():
            if isinstance(invalid, dict) and isinstance(invalid.get('Records'), list) and invalid['Records']:
                event = {'Records': [record(), *invalid['Records']]}
                with self.subTest(case=label):
                    before = copy.deepcopy(event)
                    with self.assertRaises(ValueError):
                        summarize(event)
                    self.assertEqual(event, before)


class CliTests(unittest.TestCase):
    def run_cli(self, document):
        return subprocess.run([sys.executable, '-B', str(ROOT / 's3_event_summary.py')],
                              input=document, text=True, capture_output=True, cwd=ROOT,
                              env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, timeout=10)

    def assert_error(self, document):
        result = self.run_cli(document)
        self.assertEqual(result.returncode, 2, result)
        self.assertEqual(result.stdout, '')
        self.assertTrue(result.stderr.strip())
        self.assertLess(len(result.stderr), 160)
        self.assertEqual(len(result.stderr.splitlines()), 1)
        self.assertNotIn('Traceback', result.stderr)
        self.assertNotIn('PRIVATE_MARKER', result.stderr)

    def test_005_valid_and_empty(self):
        for event, expected in [({'Records': [record(), record('other', '%E2%98%83')]},
                                 [{'bucket': 'sample-bucket', 'key': 'folder/a b+c'},
                                  {'bucket': 'other', 'key': '☃'}]), ({'Records': []}, [])]:
            with self.subTest(event=event):
                result = self.run_cli(json.dumps(event))
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, '')
                self.assertEqual(json.loads(result.stdout), expected)

    def test_006_invalid_json(self):
        for document in ('', ' ', '{', '{"PRIVATE_MARKER":', '{} {}',
                         '{"Records": [],}', "{'Records': []}", '/*PRIVATE_MARKER*/{}'):
            with self.subTest(document=document):
                self.assert_error(document)

    def test_006_invalid_events_and_later_record(self):
        for label, event in invalid_events():
            # A Python tuple is invalid directly but serializes as a valid JSON array.
            if isinstance(event, dict) and isinstance(event.get('Records'), tuple):
                continue
            with self.subTest(case=label):
                self.assert_error(json.dumps(event))
        self.assert_error(json.dumps({'Records': [record('PRIVATE_MARKER'), None]}))

    def test_006_nonstandard_constants_anywhere(self):
        for token in ('NaN', 'Infinity', '-Infinity'):
            for document in (token, '{"Records": [], "unused": ' + token + '}',
                             '{"Records": [], "unused": [{"deep": ' + token + '}]}',
                             '{"Records": [{"s3": {"bucket": {"name": "b"}, "object": {"key": "k"}}, "unused": ' + token + '}]}'):
                with self.subTest(document=document):
                    self.assert_error(document)

    def test_005_quoted_constants_remain_strings(self):
        for token in ('NaN', 'Infinity', '-Infinity'):
            event = {'Records': [record(token, token)], 'unused': token}
            result = self.run_cli(json.dumps(event))
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stderr, '')
            self.assertEqual(json.loads(result.stdout), [{'bucket': token, 'key': token}])

    def test_007_import_does_not_read_write_or_exit(self):
        code = '''
import sys
class ForbiddenStream:
    def read(self, *args): raise AssertionError("stdin read on import")
    def write(self, *args): raise AssertionError("output on import")
    def flush(self): pass
sys.stdin = sys.stdout = sys.stderr = ForbiddenStream()
import s3_event_summary
assert callable(s3_event_summary.summarize)
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
print("import completed")
'''
        result = subprocess.run([sys.executable, '-B', '-c', code], cwd=ROOT,
                                text=True, capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'import completed\n')
        self.assertEqual(result.stderr, '')


if __name__ == '__main__':
    unittest.main()
