# Full ship admission blocked before implementation

Target: specs/s3-event-summary/tasks.md#T-001 (--full)
Actual orchestrator: 01a1b5d3-5d19-7860-86a7-3d3feb8c36c4

## Authorized work and preserved state

The real human approval is reports/bootstrap/user-approval.json. Its task-after hash and all frozen artifact hashes match the current files. T-001 is Approval: Approved, Status: Planned, Risk: medium, Required Workflow: acceptance-first. No new approval event or SDD_SUDO was created. All three review stages remain Passed and their evidence is unchanged.

The user additionally requires rejecting unquoted NaN, Infinity and -Infinity anywhere in CLI JSON, including unused fields, while retaining ordinary quoted strings. This is retained here as a user-supplied clarification of the existing invalid-JSON contract; no frozen specification was edited.

## Completed preflight

- Read the installed ship, implement-tasks, implement-task and quality-gate skills and implementation/delegation policies.
- Installed check-sdd-structure.sh: OK (advisory docs/architecture only).
- Fresh actual canary denial captured in reports/bootstrap/s3-event-summary-ship-handshake.json; installed verifier returned HOOK_ACTIVE.
- Project Context remains physically absent. Track: full (--full override), compatibility fallback. acceptance-tests.md and traceability.md exist. This is not a Lite execution or model-policy managed-routing request.
- Installed check-workflow-state.sh --repository-root /workspace/.tools/sdd-forge-dev/verification-workspace/aws-notification-full: workflow-state: ok.
- Git status shows preexisting untracked workflow artifacts; no application module/tests exist and no unrelated edits were removed.

## Actual implementation admission blocker

The installed Full ship skill delegates to implement-tasks. Its Implementation Loop step 2 requires checked-in model/risk routing and a validated task-input-manifest/v1 plus immutable snapshot before work. The manifest validator requires real model_tier, provider, model, estimated_cost_per_attempt_usd, cost_estimate_source and cost_estimate_timestamp fields. The delegation policy requires filtering through the host capability registry and choosing a registered tier; model availability alone is not registry membership or cost evidence.

No agent-model-capabilities.json, agent-model-capabilities.v2.json, candidate JSON or routing JSON was found within /workspace/.tools/sdd-forge-dev/codex-verify. The consumer contracts directory contains only s3-event-summary.md. The selector's default registry path resolves to /workspace/.tools/sdd-forge-dev/codex-verify/plugins/cache/sdd-plugins/contracts/agent-model-capabilities.json, which is absent. The quality-gate's referenced v2 registry is likewise not supplied in the installed profile.

Actual installed selector command:

```sh
bash /workspace/.tools/sdd-forge-dev/codex-verify/plugins/cache/sdd-plugins/sdd-implementation/1.23.1/scripts/select-agent-model.sh --risk medium --host codex-cli --json
```

Actual stdout: BLOCKED model-tier-unavailable
Actual process exit: 0 (the legacy selector communicates refusal through stdout).
Saved output: model-selection.txt in this directory.

The no-candidate invocation does not prove that the host lacks models. It establishes that no admitted model selection was obtained from the supplied routing inputs. The host exposes fresh-agent allocation, so the incapable-host same-session reload exception does not apply. No model tier, cost estimate, fallback evidence, implementation identity or reservation was fabricated.

## Recovery boundary

Supply the trusted capability registry and authentic host candidate/cost evidence through the normal installed workflow, or repair packaging externally. Then rerun the selector and the complete manifest/snapshot/identity/output admission before any implementation. Do not edit installed scripts, synthesize registry membership or cost facts, downgrade to Lite, bypass independent evaluator isolation or implement in the author context.

No implementer was launched, no application implementation/tests were written or run, no evaluator was allocated and no quality-gate PASS or Done was claimed. Task remains Approved / Planned; this is a ship admission blocker rather than a product finding. Original ledger, approval, frozen specs and all previous diagnostics remain intact. No live AWS, deployment, credential inspection, publication, commits or installed plugin/source edits occurred.
