# Requirements: S3 event summary

Spec-Review-Status: Passed

## Overview

Source: requirements-source.md. An offline Python standard-library utility transforms S3 notification payloads into bucket/key summaries.

## Target Users

Local Python callers and command-line users processing supplied payloads.

## Problems

Callers need a small deterministic summary and consistent validation failures without accessing S3.

## Goals

REQ-001: Provide s3_event_summary.py with summarize(event), accepting a dictionary and returning a list of dictionaries containing bucket and key.

REQ-002: Decode every object key using urllib.parse.unquote_plus.

REQ-003: Reject non-dictionary events, missing/non-list Records, malformed records, and missing, empty or non-string bucket names/object keys with ValueError. Empty Records returns [].

REQ-004: CLI reads one JSON document from stdin, emits the result as JSON to stdout and exits 0; invalid JSON or invalid event emits a concise error to stderr and exits 2.

REQ-005: Use only the Python standard library, perform local payload transformation without external side effects, and include unittest coverage runnable with python3 -m unittest.

## Non-goals

S3 access, SDKs, network operations, deployment, credentials, persistence, graphical UI, event delivery or infrastructure management.

## User Stories

As a Python caller I obtain decoded bucket/key pairs or ValueError. As a CLI user I pipe JSON through the utility and distinguish valid output from errors using exit status.

## Acceptance Criteria

AC-001 (REQ-001): A valid event with multiple records returns one bucket/key dictionary per record in input order.
AC-002 (REQ-002): A key containing +, %20 and %2B is decoded exactly as urllib.parse.unquote_plus.
AC-003 (REQ-003): Records=[] returns [].
AC-004 (REQ-003): Each invalid shape or invalid required string raises ValueError, including a malformed later record.
AC-005 (REQ-004): python3 s3_event_summary.py receives valid stdin JSON, writes a JSON list matching summarize, has empty stderr and exits 0.
AC-006 (REQ-004): Invalid JSON and invalid event JSON produce nonempty concise stderr, no result on stdout, and exit 2.
AC-007 (REQ-005): python3 -m unittest discovers and passes unit and subprocess CLI tests using synthetic data, without third-party dependencies or external side effects.

## Roles and Permissions

The local caller controls input and output. No application accounts, privileged operations or authorization service.

## Main Workflows

Import summarize and pass a dictionary; or run python3 s3_event_summary.py with stdin JSON. Validation precedes returning a result; invalid input fails the whole call.

## Edge Cases

Empty list; multiple records; nested fields missing or of wrong type; empty strings; invalid JSON; a later invalid record. Validation is of raw required strings before key decoding. Extra notification fields do not affect the summary.

## Security Boundaries

| Trust Boundary | Auth/Authz Requirement | PII / Data Classification | Regulatory Constraints |
|---|---|---|---|
| Untrusted dictionary or stdin JSON → local transformation | No remote authority; local invocation only | Caller-supplied names and keys may be sensitive | No regulatory requirement supplied |

Treat names and keys as data, never as paths or commands. Errors should describe the validation problem without dumping the payload.

## Assumptions

The source requirement supplies the CLI entry and local execution preconditions. No visual interface or mockup is supplied. Standard unquote_plus behavior governs decoding; no custom percent-escape validator is required.

## Open Questions

None for the bounded source requirement.

## Risks

Malformed nested structures can leak KeyError/TypeError instead of ValueError (AC-004). Decode mistakes can change keys (AC-002). CLI stream/status confusion can break scripts (AC-005/006). Entire JSON is held in memory; no unbounded-input service or resource guarantee is promised.
