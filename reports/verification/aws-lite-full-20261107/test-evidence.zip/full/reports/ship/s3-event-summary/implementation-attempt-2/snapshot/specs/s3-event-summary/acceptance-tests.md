# Acceptance Tests: S3 event summary

All tests are Planned; implementation and execution evidence will follow task approval.

| Acceptance Criterion | Requirement | Test ID | Test Type | Test Target | Status |
|---|---|---|---|---|---|
| AC-001 | REQ-001 | TEST-001 | unit | test_s3_event_summary.py: multiple records, exact fields and order | Planned |
| AC-002 | REQ-002 | TEST-002 | unit | test_s3_event_summary.py: plus, percent escapes, Unicode and literal plus | Planned |
| AC-003 | REQ-003 | TEST-003 | unit | test_s3_event_summary.py: empty Records | Planned |
| AC-004 | REQ-003 | TEST-004 | unit | test_s3_event_summary.py: invalid event/Records and each nested shape/string | Planned |
| AC-005 | REQ-004 | TEST-005 | subprocess integration | test_s3_event_summary.py: invoke Python script with valid stdin; parse stdout, assert stderr/status | Planned |
| AC-006 | REQ-004 | TEST-006 | subprocess integration | test_s3_event_summary.py: invalid JSON and invalid events, stdout/stderr/status | Planned |
| AC-007 | REQ-005 | TEST-007 | discovery and inspection | python3 -m unittest; inspect imports and local-only behavior | Planned |

TEST-004 table: event None/list/string; Records absent/None/dict/string; record None/list/scalar; missing/non-dict s3, bucket or object; missing name/key; None, numbers, lists, dictionaries and empty strings for each required string. Include valid-first/invalid-second record to prove whole-call failure.

CLI entry is python3 s3_event_summary.py from the repository root with readable stdin and writable stdout/stderr. No GUI shell integration applies.
