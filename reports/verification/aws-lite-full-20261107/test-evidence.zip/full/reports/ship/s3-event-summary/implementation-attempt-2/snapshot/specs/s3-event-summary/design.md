# Design: S3 event summary

Impl-Review-Status: Passed
Feature Type: feature — offline Python function and CLI

## Technical Summary

A single Python 3 standard-library module with a pure summarize function and guarded CLI adapter. REQ-001–005; contracts/s3-event-summary.md.

## Architecture

stdin → JSON parser → summarize → JSON stdout; invalid JSON/event → concise stderr, exit 2. Import has no CLI side effects.

## Components

| Component | Responsibility | Public Contract | State / Failure | Technology | New/Existing |
|---|---|---|---|---|---|
| s3_event_summary.py | Validate and summarize; CLI stream/status handling | summarize(event) and script entry; contract below | In-memory only; invalid record aborts entire result | Python 3 standard library | New |

## Layer Specifications

| Layer | Summary | Canonical Detail | Owner | Status |
|---|---|---|---|---|
| UX | CLI streams | ux-spec.md | Implementer | Specified |
| Frontend | No graphical UI | frontend-spec.md | Implementer | N/A |
| Infrastructure | Local process | infra-spec.md | Implementer | Specified |
| Security | Input validation | security-spec.md | Implementer | Assessed |

## Design System Compliance

N/A — ds_profile: none

## Cross-Layer Dependencies

| From | To | Contract / Decision | REQ | AC | Verification |
|---|---|---|---|---|---|
| requirements.md | ux-spec.md | CLI streams/status | REQ-004 | AC-005, AC-006 | TEST-005, TEST-006 |
| requirements.md | security-spec.md | Validate nested input | REQ-003 | AC-004 | TEST-004 |
| security-spec.md | infra-spec.md | Local data only | REQ-005 | AC-007 | TEST-007 |

## ADR Change Log

| ADR | Decision | Status | Layer Impact | Supersedes | Date |
|---|---|---|---|---|---|
| `docs/adr/0001-s3-event-summary.md` | Single module, pure transform and CLI adapter | Proposed | Runtime/security | None | 2026-11-07 |

## Data Plan

Data Entities: Input event dictionary with Records list; records contain s3.bucket.name and s3.object.key. Output list of bucket/key dictionaries.

Existing Data Affected: None.

Migration Strategy: None; no persistence.

Preserve input order and bucket text; do not mutate input. Validate raw strings before decoding keys once with unquote_plus.

## API / Contract Plan

contracts/s3-event-summary.md owns the Python and CLI contracts. Check every container before access; missing or wrong shapes raise ValueError. Return the local result only after every record validates. Ignore unrelated fields. CLI catches JSON decoding and event ValueError and emits a concise fixed error without input values; successful serialization exits 0.

### Reviewed callable and CLI schema

The following complete contract is part of this reviewed design (REQ-001–004); contracts/s3-event-summary.md is its documentation mirror, not an additional implementation dependency.

Input: event must be a dictionary containing Records as a list. Each record must be a dictionary with s3 as a dictionary, s3.bucket as a dictionary containing name, and s3.object as a dictionary containing key. name and key must be nonempty strings, checked before decoding; unrelated fields are ignored. Missing fields, wrong container types, missing/empty/non-string name or key, including an invalid later record, raise ValueError for the whole call.

Output: summarize(event) returns a new list in input order, each dictionary containing exactly bucket (unchanged name) and key (urllib.parse.unquote_plus applied once to the raw key). Empty Records returns []. Input is not mutated; no partial result is returned. Standard unquote_plus behavior applies to percent escapes and Unicode.

CLI: python3 s3_event_summary.py reads one JSON document from stdin. Valid input produces a JSON list on stdout, empty stderr, exit 0. Invalid JSON or invalid event produces concise stderr without payload data, no result stdout, exit 2. Exact error wording and JSON whitespace are unspecified. A main guard prevents CLI execution on import.

Compatibility: this is a new local module and script with no existing caller contract to migrate, deprecate or break. No public service endpoint or protocol is introduced. No contract version negotiation is needed for this initial capability.

## Test Strategy

TEST-001–007 in acceptance-tests.md cover exact transformation, unquote_plus semantics, invalid-shape tables and subprocess stream/status behavior. Run python3 -m unittest. No third-party dependencies or services.

Acceptance coverage: AC-001 → TEST-001 verifies exact fields and input order; AC-002 → TEST-002 verifies unquote_plus decoding; AC-003 → TEST-003 verifies empty Records. AC-004 → TEST-004 covers all invalid shapes and whole-call failure. AC-005/AC-006 → TEST-005/TEST-006 cover success/error CLI streams and exit status. AC-007 → TEST-007 covers unittest discovery and local standard-library-only execution.

## Security Boundaries

| Trust Boundary | Auth/Authz Mechanism | Data Classification | OWASP Concerns |
|---|---|---|---|
| Local input → transform | Local invocation only | Potentially sensitive names/keys | Validation; avoid payload disclosure |

Details: security-spec.md.

## Deployment / CI Plan

Local validation: python3 -m unittest. No deployment or CI change. Details: infra-spec.md.

## Constraint Compliance

| Requirement Constraint | Design Response |
|---|---|
| REQ-005 standard library and local only | json, sys, urllib.parse; no SDK, network or storage |
| Names and keys must never be interpreted as paths or commands | Only validate/copy strings and decode keys; no file opening, path resolution, shell command construction or execution using input values (security-spec.md#owasp-mapping) |
| Errors must not dump caller payloads | CLI emits fixed concise validation/JSON error text to stderr without names, keys, raw JSON or traceback (security-spec.md#stride-analysis); TEST-006 exercises payload-free error handling |
| REQ-001–003 shape, decoding and whole-call validation | Reviewed callable schema above; TEST-001–004 cover exact output, empty input and invalid nested values |
| REQ-004 CLI streams and status | Reviewed CLI schema above; TEST-005/006 validate stdout, stderr and status |

## Assumptions

Python 3 is available as python3; standard unquote_plus behavior applies. No input-size or latency guarantee is added.

## Open Questions

None for the bounded source requirement.

## Risks

Normalize nested failures to ValueError (TEST-004); decode exactly (TEST-002); validate streams/status through the actual process (TEST-005/006).
