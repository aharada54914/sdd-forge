# AWS S3 notification local utility

Offline workflow verification project. No deployment, credentials, SDK, or live cloud operations.
