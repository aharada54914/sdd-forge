import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import tomllib

ROOT = Path.cwd()
INST = Path('/workspace/.tools/sdd-forge-dev/codex-verify/plugins/cache/sdd-plugins')
QUALITY = INST / 'sdd-quality-loop/1.23.1'
LAUNCHER = INST / 'sdd-review-loop/1.23.1/scripts/launch-codex-review.py'
spec = importlib.util.spec_from_file_location('native_evaluator_transport', LAUNCHER)
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
CONTROL = ROOT / 'reports/quality-gate/s3-event-summary-evaluator-1'
CONTROL.mkdir(parents=True, exist_ok=False)
SCRATCH = Path(tempfile.mkdtemp(prefix='s3-event-summary-evaluator-'))
OUTSIDE = SCRATCH.parent / (SCRATCH.name + '-outside-probe')
OUTSIDE.write_text('not admitted')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
pin = lambda p: dict(path=str(Path(p).relative_to(ROOT)), sha256=sha(p))
save = lambda n, d: (CONTROL / n).write_text(json.dumps(d, indent=2) + '\n')
cli = Path(shutil.which('codex')).resolve()
command = native.command_base(cli, SCRATCH)
command += ['-c', 'model="gpt-6-astra"', '-c', 'model_reasoning_effort="medium"']
save('native-command.json', command)
role_path = Path('/workspace/.tools/sdd-forge-dev/codex-verify/agents/sdd-evaluator.toml')
role = tomllib.loads(role_path.read_text())
(CONTROL / 'model-reference-drift.txt').write_text('DRIFT: shipped sdd-evaluator.toml comments openai/gpt-5.2-codex/high; live registry selector gpt-6-astra/medium (risk-matrix, strong). Native launch uses live selection through model and model_reasoning_effort config controls.\n')
rpc = native.Rpc(command, SCRATCH, CONTROL, 1200)
try:
    native.initialize(rpc)
    config = rpc.request('config/read', {'includeLayers': False}, record=False)['config']
    assert config['model'] == 'gpt-6-astra' and config['model_reasoning_effort'] == 'medium'
    assert config['web_search'] == 'disabled'
    assert not config.get('mcp_servers'), 'External MCP servers must not be inherited'
    save('model-control-observation.json', {k: config[k] for k in ('model', 'model_reasoning_effort')})
    save('permission-probes.json', native.probe_permissions(rpc, SCRATCH, OUTSIDE))
    allocation = rpc.request('thread/start', {'cwd': str(SCRATCH), 'model': 'gpt-6-astra',
        'permissions': native.PROFILE, 'approvalPolicy': 'never', 'selectedCapabilityRoots': [],
        'baseInstructions': 'Independent read-only SDD evaluator. Read only invocation and admitted projection files. No writes, network, external tools, delegation, inherited implementation history, or raw peer reviews. Return the shipped evaluator format.',
        'developerInstructions': role['developer_instructions'],
        'config': {'project_doc_max_bytes': 0, 'model_reasoning_effort': 'medium'}})
    save('idle-allocation.json', allocation)
    thread = allocation['thread']
    ident = thread['id']
    assert not thread['turns'] and thread['status']['type'] == 'idle'
    assert allocation['activePermissionProfile']['id'] == native.PROFILE
    report = ROOT / 'reports/implementation/s3-event-summary/T-001.md'
    manifest = ROOT / 'reports/ship/s3-event-summary/implementation-attempt-3/control/task-input-manifest.json'
    base = ROOT / 'specs/s3-event-summary/verification/T-001/gate-1'
    extra = [ROOT / 'contracts/s3-event-summary.md', ROOT / 'docs/adr/0001-s3-event-summary.md',
        ROOT / 'specs/s3-event-summary/verification/T-001.contract.json']
    extra += [p for p in base.rglob('*') if p.is_file() and p.suffix != '.pyc']
    # Review-frozen report remains the identity and output authority.
    declaration = dict(schema='supplemental-delivery-declaration/v1', feature='s3-event-summary',
        task_id='T-001', implementation_report=pin(report), artifacts=[pin(p) for p in extra])
    declaration_path = base.parent / 'evaluator-delivery-1.json'
    assert not declaration_path.exists()
    declaration_path.write_text(json.dumps(declaration, indent=2) + '\n')
    paths = list((ROOT / 'specs/s3-event-summary').glob('*.md'))
    paths += [ROOT / 'plugins/sdd-quality-loop/references/quality-gate-calibration.md', report, manifest,
        declaration_path, ROOT / 's3_event_summary.py', ROOT / 'test_s3_event_summary.py', ROOT / 'README.md',
        ROOT / 'specs/s3-event-summary/verification/T-001/unittest.txt'] + extra
    paths = list(dict.fromkeys(paths))
    ledger_path = ROOT / 'reports/review-context/identity-ledger.json'
    tip = json.loads(ledger_path.read_text())['records'][-1]
    invocation = dict(schema='review-context-invocation/v2', stage='quality', role='sdd-evaluator',
        feature='s3-event-summary', task_id='T-001', input_mode='file-manifest', fallback_mode='none',
        read_only=True, run_id=ident, host_session_id=ident,
        identity_ledger_path='reports/review-context/identity-ledger.json',
        identity_ledger_sha256=sha(ledger_path), sequence=tip['sequence']+1,
        previous_record_sha256=tip['record_sha256'], scratch_root=str(SCRATCH),
        implementation_manifest=pin(manifest), supplemental_delivery_declaration=pin(declaration_path),
        allowed_input_manifest=[pin(p) for p in paths])
    save('invocation.json', invocation)
    invpath = CONTROL / 'invocation.json'
    invhash = sha(invpath)
    for p in paths:
        target = SCRATCH / p.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(p.read_bytes())
        assert sha(target) == sha(p)
    args = ['python3', '-B', str(QUALITY / 'scripts/preflight-evaluator-delivery.py'),
        '--manifest', str(invpath), '--manifest-sha256', invhash,
        '--repository-root', str(ROOT), '--scratch-root', str(SCRATCH)]
    def preflight(name, command):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        (CONTROL / name).write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        return result.stdout
    preflight('delivery-preflight.txt', args)
    receipt = preflight('reservation.txt', args + ['--reserve'])
    assert 'EVALUATOR_DELIVERY_OK' in receipt and 'REVIEW_CONTEXT_OK' in receipt
    target = SCRATCH / invpath.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(invpath.read_bytes())
    brief = f'''Read the invocation at {invpath.relative_to(ROOT)}. Its raw SHA-256 is {invhash}. Canonical original path for your ALLOWED_INPUT_MANIFEST declaration: {invpath.relative_to(ROOT)}. Your identity is {ident}. Verify raw pin, receipt chain and every admitted input before substantive inspection. Do not read the identity ledger or reserve again.
Caller receipt:\n{receipt}
Scratch is your sole read-only projection: {SCRATCH}. Read only admitted relative paths there. No writes even to scratch; use python3 -B and PYTHONDONTWRITEBYTECODE=1 for any read-only rerun. No live services, network, credentials, installed edits or task/status mutations. No Lite fixture or peer review output is supplied or authorized.
Apply the admitted calibration, evaluation rubric, security and performance checklists. Verify each AC through direct/subprocess tests and line-level code inspection; implementation report is a claim. Inspect gate-time outputs honestly, including any failing required check. Strict JSON constants user clarification is admitted. Return the shipped evaluator text format with identity and manifest pin, actual findings and CHECKED evidence. Delivery is not a PASS. Native selector uses gpt-6-astra/medium, strong risk-matrix; old TOML model comments are reference drift only.'''
    (CONTROL / 'launch-brief.txt').write_text(brief)
    result = rpc.request('turn/start', {'threadId': ident, 'permissions': native.PROFILE,
        'approvalPolicy': 'never', 'input': [{'type': 'text', 'text_elements': [], 'text': brief}]})
    turn = result['turn']['id']
    messages = []
    while True:
        event = rpc.events.pop(0) if rpc.events else rpc.receive()
        params = event.get('params', {})
        if event.get('method') == 'item/completed' and params['item'].get('type') == 'agentMessage':
            messages.append(params['item']['text'])
        if event.get('method') == 'turn/completed':
            assert params['turn']['id'] == turn and params['turn']['status'] == 'completed'
            break
    for p in paths:
        assert sha(p) == next(e['sha256'] for e in invocation['allowed_input_manifest'] if e['path'] == str(p.relative_to(ROOT)))
    raw = '\n'.join(messages) + '\n'
    (CONTROL / 'evaluator.txt').write_text(raw)
    assert re.search(r'^RUN_ID: ' + re.escape(ident) + r'$', raw, re.M)
    assert re.search(r'^HOST_SESSION_ID: ' + re.escape(ident) + r'$', raw, re.M)
    assert invhash in raw and re.search(r'^VERDICT: (PASS|NEEDS_WORK)$', raw, re.M)
    save('delivery.json', dict(schema='native-evaluator-delivery/v1', run_id=ident,
        host_session_id=ident, invocation_sha256=invhash, evaluator_sha256=sha(CONTROL/'evaluator.txt'),
        adoption='requires-quality-gate-adjudication'))
    print('EVALUATOR_CANDIDATE ' + str(CONTROL / 'evaluator.txt'), flush=True)
finally:
    rpc.close()
