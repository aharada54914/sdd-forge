# Task reviewer B preflight recovery

The first launch-b returned CODEX_REVIEW_REJECTED: required stage inputs differ or changed, before reservation or a reviewer turn. Its allocated idle identity and native probe logs are preserved. The canonical ledger still ended at sequence 8, task-reviewer-a, and launch-b had no reservation.stdout or candidate.

The author had incorrectly reused reviewer A's dependency-graph input set. The installed launch-impl-review.py required_input_paths procedure specifies dependency-graph.json for task reviewer A only; task reviewer B instead requires risk-gate-matrix.md and risk-classification-policy.md, plus the current sanitized summary. The corrected template removes the graph and adds exactly those two installed/precheck-projected policy references with their actual SHA-256 hashes. It preserves all other inputs and the real reviewer A summary. No product artifact changed.

The original manifest and failed launch directory remain untouched. The retry uses reviewer-b-invocation-template-corrected.json and a new launch-b-corrected directory, with a newly allocated idle native identity. No identity or partial output is reused; canonical permission probes, preflight and reservation remain required.
