# S3 event summary contract

Source: REQ-001–005; AC-001–007.

`summarize(event)` in `s3_event_summary.py` accepts a dictionary whose `Records` value is a list. Each record is a dictionary with dictionary `s3`, dictionary `bucket` containing `name`, and dictionary `object` containing `key`. Both required values must be nonempty strings. Empty Records is valid. Extra fields are ignored.

Return a new list in record order, containing exactly `bucket` (unchanged name) and `key` (urllib.parse.unquote_plus applied once). Do not mutate the input. Invalid event/container/required string raises ValueError; a malformed later record fails the whole call, with no partial return. Raw strings are validated before decoding; standard decoder semantics govern percent escapes and Unicode.

CLI: `python3 s3_event_summary.py`, one JSON document from stdin. Success writes a JSON result and exits 0 with empty stderr. Invalid JSON or invalid event writes a concise error to stderr, no result to stdout, and exits 2. Exact error wording and JSON whitespace are not contractual. No payload dump in errors. Import must not run the CLI. No external side effects or third-party dependencies.
