# Tasks: S3 event summary

Task-Review-Status: Passed

## Lifecycle

`Draft -> Approved -> In Progress -> Implementation Complete -> Done`

A task may enter `Blocked` from any active state. Humans approve tasks.
`implement-task` may set `In Progress`, `Blocked`, or `Implementation Complete`.
Only `quality-gate` may set `Done`.

## T-001 Implement offline S3 event summary with unittest coverage

Source Issue: requirements-source.md (local supplied requirement)

Approval: Approved

Status: Done

Risk: medium

Risk Impact: limited

Risk Reversibility: controlled

Risk Surface: behavioral

Risk Rationale: REQ-001–005 introduce bounded local transformation behavior; no authentication, authorization, payments, stored PII, mutation/migration, remote public API or external side effects. Classification is proposed for human confirmation.

Required Workflow: acceptance-first

Requirements: REQ-001, REQ-002, REQ-003, REQ-004, REQ-005; AC-001, AC-002, AC-003, AC-004, AC-005, AC-006, AC-007

Planned Files: s3_event_summary.py; test_s3_event_summary.py; README.md; reports/implementation/s3-event-summary/T-001.md; specs/s3-event-summary/verification/T-001/ (saved validation output). Only lifecycle status cells in traceability.md may advance.

Data Migration: None; no persistence.

Breaking API: No; initial local module/script, no existing caller contract changed.

### Goal
Deliver the pure summarize(event) transformation and stdin/stdout CLI specified by REQ-001–005 and AC-001–007.

### Must Read
- specs/s3-event-summary/requirements.md
- specs/s3-event-summary/design.md
- specs/s3-event-summary/acceptance-tests.md
- specs/s3-event-summary/traceability.md

### Scope
1. Before/with implementation, write standard-library unittest acceptance tests TEST-001–007, including subprocess invocation of the real script. Use only synthetic payloads and the cases in acceptance-tests.md.
2. Implement s3_event_summary.py according to design.md#reviewed-callable-and-cli-schema: explicit container and nonempty-string validation, whole-call ValueError, one unquote_plus decoding pass, ordered fresh result, main-guarded JSON stdin/stdout CLI and concise payload-free stderr/status 2 on invalid input.
3. Add local invocation and import examples, success/error exit behavior and python3 -m unittest instructions to README.md. Save command output and the implementation report; keep evidence in the non-frozen verification directory.

Risk input is requirements-source.md; no execution-environment constraints are feature requirements. This adds an initial local interface, not a change to an externally deployed API or a cloud integration. Acceptance-first means the acceptance cases are defined before/with the implementation; no live service or third-party package is needed.

### Done When
- [ ] s3_event_summary.py exposes summarize(event) with exact bucket/key output, unquote_plus decoding and empty-list behavior (AC-001–003 / TEST-001–003), without mutating input.
- [ ] test_s3_event_summary.py exercises every invalid container/string case and a later malformed record, observing ValueError for the whole call (AC-004 / TEST-004).
- [ ] Subprocess tests observe valid JSON stdout/empty stderr/status 0 and invalid JSON/event empty stdout/concise payload-free stderr/status 2 (AC-005–006 / TEST-005–006).
- [ ] python3 -m unittest passes all discovered tests; its output is saved at specs/s3-event-summary/verification/T-001/unittest.txt. Inspection recorded in T-001.md confirms standard-library-only imports and local transformation with no external side effects (AC-007 / TEST-007).
- [ ] README.md contains executable local CLI/import examples and the validation command, and reports/implementation/s3-event-summary/T-001.md records changed files, AC/TEST results and evidence paths.
- [ ] Delivery-status cells for REQ-001–005 in traceability.md reflect only saved lifecycle evidence; its requirement, task, code and test mappings stay unchanged.
- [ ] The independent quality-gate report names T-001 and records its verification result; only that gate may set Done.

### Out of Scope
AWS/S3 access, SDKs, network, credentials, persistence, deployment, remote APIs, graphical UI, package installation and unrelated changes. No edits to review-frozen design/layer documents, task body or traceability mappings during implementation.

### Blockers
None

Rollback: Remove the new local module/test and restore the prior README if the capability is withdrawn; no stored data or infrastructure needs recovery.
