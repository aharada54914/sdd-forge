import difflib, hashlib, json, pathlib, shutil, subprocess, sys
BASE=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path('/workspace/sdd-forge')
MAIN=pathlib.Path('/workspace/scratch/sdd-forge-main-integration')
ROOT=BASE/'packet-workspace'
ROOT.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def ref(p): return {'path':p,'sha256':sha((ROOT/p).read_bytes())}
def head(p): return subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip()
script='plugins/sdd-bootstrap/scripts/decision-packet.py'
protocol={'schema':'historical-packet-integration-evaluation/v1','source_head':head(SOURCE),'candidate_head':head(MAIN),'source_cli_sha256':sha((SOURCE/script).read_bytes()),'candidate_cli_sha256':sha((MAIN/script).read_bytes()),'criteria':['real CLI JSON and Markdown exit zero','two historical previews and original log paths/hashes present and resolvable','source log mutation rejected','each preview mutation rejected','selected packet mutation rejected','restoration passes','no signed choice and human decision pending'],'human_time':None,'new_human_choice':None,'real_app_acceptance':'pending; fixture-only integration of historical evidence','model_comparison':'not performed'}
save(BASE/'protocol.json',protocol)
paths=['mcp-real-app-20261027/observations.json','mcp-real-app-20261027/review-data.json','mcp-real-app-20261027/protocol.json','mcp-real-app-v2-20261027/review.html','mcp-real-app-v2-20261027/owner-feedback.json','mcp-real-app-v3-20261027/review.html','mcp-real-app-v3-20261027/owner-choice.json','mcp-real-app-v3-20261027/feedback.json','mcp-real-app-v3-20261027/handoff.md']
inventory=[]
for name in paths:
    origin=SOURCE/'reports/verification'/name
    dest=ROOT/'historical'/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(origin,dest)
    inventory.append({'source':str(origin),'copy':str(dest.relative_to(ROOT)),'sha256':sha(dest.read_bytes())})
save(BASE/'source-inventory.json',inventory)
(ROOT/'specs/pilot').mkdir(parents=True,exist_ok=True)
(ROOT/'specs/pilot/tasks.md').write_text('## T-001 Historical packet fixture\nApproval: Draft\nStatus: Planned\n')
raw='historical/mcp-real-app-20261027/observations.json'
p2='historical/mcp-real-app-v2-20261027/review.html';p3='historical/mcp-real-app-v3-20261027/review.html'
(ROOT/'preview.diff').write_text(''.join(difflib.unified_diff((ROOT/p2).read_text().splitlines(True),(ROOT/p3).read_text().splitlines(True),fromfile=p2,tofile=p3)))
packet={'schema':'decision-packet/v1','feature':'pilot','task':'T-001','run_id':'historical-packet-integration','objective':'Inspect stored MCP display alternatives and original response evidence','scenario':'Locate state, reason, next step and later phases in historical previews','hypotheses':['Readable display may assist checking; no new human evaluation performed'],'inputs':[ref(raw),ref('historical/mcp-real-app-20261027/review-data.json')],'approval':ref('specs/pilot/tasks.md'),'alternatives':[],'recommendation':{'alternative':None,'reason':'Historical choice retained as input evidence only, not a new authenticated packet selection'},'unknowns':['Human active time, waiting time, operation errors and blinded task completion unmeasured'],'risks':['Stored static snapshots; no current live-app or backend evaluation'],'next_action':'Keep real-app acceptance pending; inspect historical source without authorizing tasks','previous':None,'concept_test':False}
for name,preview,feedback in [('v2',p2,'historical/mcp-real-app-v2-20261027/owner-feedback.json'),('v3',p3,'historical/mcp-real-app-v3-20261027/owner-choice.json')]:
    packet['alternatives'].append({'id':name,'description':'Historical '+name+' snapshot; not a new experimental condition','preview':ref(preview),'diff':ref('preview.diff'),'observations':[{'outcome':'unknown','reason':'Historical raw responses retained; no packet-bound measurement, no success re-attestation','evidence':ref(raw),'measurement':None},{'outcome':'unknown','reason':'Historical human feedback only; not signed choice or task approval for this packet','evidence':ref(feedback),'measurement':None}],'counterevidence':['Prior displays were rejected; historical iterations are not matched blinded samples'],'unknowns':['Current human operation outcome and time']})
save(ROOT/'packet.json',packet)
digest=sha(json.dumps(packet,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
cmd=[sys.executable,str(MAIN/script),'--root',str(ROOT),'--packet','packet.json','--feature','pilot','--task','T-001','--run-id','historical-packet-integration','--packet-sha256',digest]
results=[]
def run(name,fmt='markdown',reject=False):
    proc=subprocess.run(cmd+['--format',fmt],capture_output=True,text=True)
    (BASE/(name+'.stdout')).write_text(proc.stdout);(BASE/(name+'.stderr')).write_text(proc.stderr)
    ok=(proc.returncode!=0 and 'invalid-or-stale-packet' in proc.stdout) if reject else proc.returncode==0
    results.append({'case':name,'argv':cmd+['--format',fmt],'exit':proc.returncode,'pass':ok})
    assert ok,(name,proc.stdout,proc.stderr)
    return proc.stdout
out=run('baseline-json','json');assert json.loads(out)['human_decision']=='pending'
md=run('baseline-markdown')
for p in [raw,p2,p3]: assert p in md and ref(p)['sha256'] in md and (ROOT/p).is_file()
assert 'Human alternative decision: pending' in md
for name,path in [('source-mutation',raw),('v2-preview-mutation',p2),('v3-preview-mutation',p3),('packet-mutation','packet.json')]:
    target=ROOT/path;original=target.read_bytes()
    try:
        if path=='packet.json':
            altered=json.loads(original);altered['objective']='replaced';save(target,altered)
        else: target.write_bytes(original+b'\nmodified\n')
        run(name,reject=True)
    finally: target.write_bytes(original)
run('restored')
assert all(sha((ROOT/r['copy']).read_bytes())==r['sha256'] for r in inventory)
save(BASE/'results.json',{'protocol':protocol,'packet_sha256':digest,'cases':results,'all_passed':True,'reachability':'rendered relative paths and hashes resolve to byte-identical local historical copies; no preview browser execution','authority':'none','remaining':['real application two-option measured evaluation','human preparation/check/wait comparison','signed choice not issued','no #624 completion']})
print(json.dumps({'all_passed':True,'cases':len(results),'output':str(BASE)}))
