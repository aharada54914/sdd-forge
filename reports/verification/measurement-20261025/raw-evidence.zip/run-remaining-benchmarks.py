import json,os,pathlib,subprocess,time
base=pathlib.Path('/workspace/scratch/issue-resolution-20261025')
deadline=time.monotonic()+1800
while not (base/'benchmark-baseline/results.json').exists():
    if time.monotonic()>deadline: raise SystemExit('baseline did not finish')
    time.sleep(2)
runs=[
 ('benchmark-feature-baseline','benchmark-feature.json','c5a02f06','--run'),
 ('benchmark-feature-candidate','benchmark-feature.json','dc0c17c24aff554e2535281ac5d9ee5f1db389b0','--run'),
 ('benchmark-feature-overhead','benchmark-feature.json','dc0c17c24aff554e2535281ac5d9ee5f1db389b0','--overhead'),
 ('benchmark-candidate','benchmark.json','dc0c17c24aff554e2535281ac5d9ee5f1db389b0','--run')]
records=[]
for name,manifest,revision,mode in runs:
    argv=['python3','tests/benchmark-gates.py','--manifest','tests/fixtures/run-measurement/'+manifest,'--output',str(base/name),'--code-revision',revision,mode]
    with (base/(name+'.log')).open('w') as output:
        p=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT)
    records.append({'name':name,'argv':argv,'exit_code':p.returncode})
    (base/'benchmark-orchestration.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    if p.returncode: raise SystemExit(p.returncode)
