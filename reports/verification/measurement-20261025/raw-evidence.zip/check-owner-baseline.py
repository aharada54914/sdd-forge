import hashlib,importlib.util,json,pathlib,subprocess,sys,tempfile
root=pathlib.Path('/workspace/sdd-forge');out=pathlib.Path('/workspace/scratch/issue-resolution-20261025/owner-baseline-controls');out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('integration',root/'tests/run-measurement-integration.tests.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
records=[]
for code in (0,3):
 f=t.OwnerIntegration();f.setUp()
 try:
  path=f.root/'tests/verification.py';path.write_bytes(subprocess.check_output(['git','-C',str(root),'show','c5a02f06:tests/verification.py']))
  a,ra,_,_=f.run_owner(code)
  path.write_bytes((root/'tests/verification.py').read_bytes());b,rb,_,_=f.run_owner(code,True)
  for row in ra['results']+rb['results']:row.pop('seconds')
  equal=(a.returncode,a.stdout,a.stderr,ra)==(b.returncode,b.stdout,b.stderr,rb)
  for label,p,v in [('base',a,ra),('candidate',b,rb)]:
   (out/f'verification-{code}-{label}.stdout').write_bytes(p.stdout);(out/f'verification-{code}-{label}.stderr').write_bytes(p.stderr);(out/f'verification-{code}-{label}.json').write_text(json.dumps(v,sort_keys=True))
  records.append({'owner':'verification','exit':code,'equal':equal,'normalization':['results.seconds']})
 finally:f.tmp.cleanup()
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp);(p/'scripts').mkdir();old=p/'baseline-lite.py';old.write_bytes(subprocess.check_output(['git','-C',str(root),'show','c5a02f06:plugins/sdd-lite/lib/run-lite-gate.py']))
 for name,body in [('pass','exit 0'),('fail','exit 3'),('timeout','sleep 5')]:
  (p/'scripts'/f'{name}.sh').write_text(body+'\n');(p/'scripts'/f'{name}.ps1').write_text('exit 0\n')
  flags=['--repo-root',str(p),'--runtime','posix','--enforcement','none','--check',name,'--timeout','0.05']
  a=subprocess.run([sys.executable,str(old),*flags],capture_output=True);b=subprocess.run([sys.executable,str(root/'plugins/sdd-lite/lib/run-lite-gate.py'),*flags,'--measure-dir',str(p/('measure-'+name))],capture_output=True)
  ra,rb=json.loads(a.stdout),json.loads(b.stdout)
  for value in (ra,rb):
   value.pop('recorded_at')
   for row in value['checks']:row.pop('duration_ms')
  equal=(a.returncode,a.stderr,ra)==(b.returncode,b.stderr,rb)
  for label,r,v in [('base',a,ra),('candidate',b,rb)]:
   (out/f'lite-{name}-{label}.stdout').write_bytes(r.stdout);(out/f'lite-{name}-{label}.stderr').write_bytes(r.stderr);(out/f'lite-{name}-{label}.json').write_text(json.dumps(v,sort_keys=True))
  records.append({'owner':'lite','case':name,'equal':equal,'normalization':['recorded_at','checks.duration_ms']})
result={'baseline':'c5a02f06c2aa6d6b287c0b81e203ce0d65f96620','candidate':'dc0c17c24aff554e2535281ac5d9ee5f1db389b0','cases':records}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(not all(x['equal'] for x in records))
