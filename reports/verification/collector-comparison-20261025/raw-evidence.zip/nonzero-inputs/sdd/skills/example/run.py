print("real failing invocation")
raise SystemExit(3)
