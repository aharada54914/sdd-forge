import pathlib,subprocess,json,time,sys
base=pathlib.Path('/workspace/scratch/workflow-session-comparison-20261025');probe=pathlib.Path('/workspace/sdd-forge/reports/verification/workflow-session-comparison-20261025/probe.py');source=pathlib.Path('/workspace/sdd-forge');deadline=time.monotonic()+600
while not (base/'original-batch/result.json').exists():
 if time.monotonic()>deadline:raise SystemExit('original batch unfinished')
 time.sleep(2)
rows=[]
scenarios=[('original',1),('pending48',5),('invalid48',3)]
for fixture,count in scenarios:
 for number in range(count):
  order=['baseline'] if fixture=='original' else ['baseline','batch'] if number%2==0 else ['batch','baseline']
  for mode in order:
   name=f'{fixture}-{number}-{mode}';argv=[sys.executable,str(probe),'--source-root',str(source),'--registry',str(base/fixture/'specs/workflow-state-registry.json'),'--mode',mode,'--requests','2','--output',str(base/name)]
   began=time.monotonic_ns();result=subprocess.run(argv,capture_output=True);elapsed=time.monotonic_ns()-began
   (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
   rows.append(dict(name=name,argv=argv,exit_code=result.returncode,outer_process_ns=elapsed))
   (base/'matrix-execution.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,result.returncode,result.stdout.decode().strip(),flush=True)
   if result.returncode:raise SystemExit(result.returncode)
