import pathlib,subprocess,json,time,sys
base=pathlib.Path('/workspace/scratch/workflow-session-comparison-20261025');probe=pathlib.Path('/workspace/sdd-forge/reports/verification/workflow-session-comparison-20261025/probe.py');rows=[]
for requests in [5,10]:
 for number in range(3):
  for mode in (['baseline','batch'] if number%2==0 else ['batch','baseline']):
   name=f'pending48-n{requests}-{number}-{mode}';argv=[sys.executable,str(probe),'--source-root','/workspace/sdd-forge','--registry',str(base/'pending48/specs/workflow-state-registry.json'),'--mode',mode,'--requests',str(requests),'--output',str(base/name)]
   began=time.monotonic_ns();result=subprocess.run(argv,capture_output=True);elapsed=time.monotonic_ns()-began
   (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
   rows.append(dict(name=name,argv=argv,exit_code=result.returncode,outer_process_ns=elapsed));(base/'extra-execution.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,result.returncode,result.stdout.decode().strip(),flush=True)
   if result.returncode:raise SystemExit(result.returncode)
