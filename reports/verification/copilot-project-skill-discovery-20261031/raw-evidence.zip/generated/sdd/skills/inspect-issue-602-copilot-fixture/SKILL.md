---
name: inspect-issue-602-copilot-fixture
description: Read the synthetic fixture note without changing files.
---
Read notes.txt and describe its contents. Do not modify files or use network services. Discovery is not execution evidence.
