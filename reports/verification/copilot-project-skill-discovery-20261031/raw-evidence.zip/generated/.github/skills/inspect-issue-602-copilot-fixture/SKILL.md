---
name: inspect-issue-602-copilot-fixture
description: Read the synthetic fixture note without changing files.
---

Read and follow [the canonical project skill](../../../sdd/skills/inspect-issue-602-copilot-fixture/SKILL.md).
Keep its prerequisites, allowed effects, observations and cleanup unchanged.
