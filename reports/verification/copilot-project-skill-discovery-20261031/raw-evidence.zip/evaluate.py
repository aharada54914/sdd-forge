import hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('/workspace/scratch/sdd-forge-main-integration')
CLI='/workspace/.tools/sdd-forge-host-smoke/node_modules/.bin/copilot'
PROFILE='/workspace/.tools/sdd-forge-host-smoke/profiles/copilot'
NAME='inspect-issue-602-copilot-fixture'
PRODUCT=ROOT/'plugins/sdd-bootstrap/scripts/project-skill.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,COPILOT_HOME=PROFILE,NO_COLOR='1')
result={'rubric':['absent before projection','native list discovers exact generated skill','absent after removing projection'],'model_execution':'not-run','authentication_attempt':'not-run','commands':[],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in (PRODUCT,ROOT/'plugins/sdd-quality-loop/scripts/validate-project-skill.py')}}
workspace=pathlib.Path(tempfile.mkdtemp(prefix='copilot-discovery-'))
def run(label,args):
 p=subprocess.run(args,cwd=workspace,env=env,capture_output=True,text=True,timeout=30)
 (OUT/(label+'.stdout.txt')).write_text(p.stdout);(OUT/(label+'.stderr.txt')).write_text(p.stderr)
 result['commands'].append({'label':label,'argv':args,'exit_code':p.returncode})
 return p
try:
 version=run('version',[CLI,'--version']);result['version']=version.stdout.strip()
 baseline=run('before',[CLI,'skill','list'])
 assert baseline.returncode==0, 'baseline skill list failed'
 assert NAME not in baseline.stdout
 skill=workspace/'sdd/skills'/NAME;skill.mkdir(parents=True)
 (workspace/'notes.txt').write_text('Synthetic note for read-only discovery evaluation.\n')
 (skill/'SKILL.md').write_text(f'---\nname: {NAME}\ndescription: Read the synthetic fixture note without changing files.\n---\nRead notes.txt and describe its contents. Do not modify files or use network services. Discovery is not execution evidence.\n')
 (skill/'run.py').write_text('from pathlib import Path\nprint(Path("notes.txt").read_text())\n')
 for label,args in [('seal',['seal','--runtime','python3','--entry','run.py','--check','read-note']),('project',['project','--host','copilot'])]:
  p=run(label,[sys.executable,str(PRODUCT),*args,'--root',str(workspace),'--name',NAME]);assert p.returncode==0,(label,p.stderr)
 wrapper=workspace/'.github/skills'/NAME/'SKILL.md'
 for rel in ['sdd/skills/'+NAME+'/SKILL.md','sdd/skills/'+NAME+'/skill-manifest.json','.github/skills/'+NAME+'/SKILL.md','sdd/skill-projections.json']:
  dest=OUT/'generated'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(workspace/rel,dest)
 result['wrapper_sha256']=sha(wrapper)
 projected=run('projected',[CLI,'skill','list']);assert projected.returncode==0
 result['native_discovery']=NAME in projected.stdout
 assert result['native_discovery'],'projected skill absent from native list'
 shutil.rmtree(workspace/'.github/skills'/NAME)
 cleaned=run('cleaned',[CLI,'skill','list']);assert cleaned.returncode==0
 result['absent_after_cleanup']=NAME not in cleaned.stdout;assert result['absent_after_cleanup']
 result['status']='passed'
except Exception as e:
 result['status']='failed';result['error']=str(e)
finally:
 shutil.rmtree(workspace)
 result['temporary_workspace_removed']=not workspace.exists()
 result['product_sources_unchanged']=all(sha(ROOT/p)==v for p,v in result['source_sha256'].items())
 (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
