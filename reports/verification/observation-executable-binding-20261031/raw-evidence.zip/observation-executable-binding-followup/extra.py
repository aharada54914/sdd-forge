import importlib.util,json,pathlib
ROOT=pathlib.Path('/workspace/scratch/sdd-forge-main-integration');OUT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('fixture',ROOT/'tests/project-skill-lifecycle.tests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);a=m.A
results={}
for scenario in ('output','inside','external'):
 t=m.Lifecycle();t.setUp()
 try:
  source={'output':'from pathlib import Path\np=Path("output/tool.sh");p.parent.mkdir();p.write_text("#!/bin/sh\\nexit 0\\n");p.chmod(0o751)\n','inside':'from pathlib import Path\nPath("sdd/skills/verify-app/run.py").chmod(0o755)\n','external':f'from pathlib import Path\nPath({str(t.skill/"run.py")!r}).chmod(0o755)\n'}[scenario]
  t.seal(source);(t.skill/'run.py').chmod(0o644);task=t.task_manifest();r=t.run_skill(task_path=task)
  row={'outcome':r['outcome'],'reason':r.get('reason'),'observation_written':r['observation_written']}
  if scenario=='output':
   row['output_mode']=oct((t.root/'output/tool.sh').stat().st_mode&0o777)
   obs=t.root/r['observation'];v=a.V.validate(t.root,'verify-app',obs,task);row['projected']=a.V.project_execution({'id':'smoke','required':True},v)
   assert (t.root/'output/tool.sh').stat().st_mode & 0o111 == 0o111 # only executable bits preserved; rw modes follow publication defaults
   assert row['projected']['passes']
   old=json.loads(obs.read_text());old['schema']='project-verification-observation/v2';old['source'].pop('executable_modes_sha256');obs.write_text(json.dumps(old))
   v=a.V.validate(t.root,'verify-app',obs,task);row['v2_state']=v[2];row['v2_projection']=a.V.project_execution({'id':'smoke','required':True},v)
   assert row['v2_state']=='legacy-source-modes-unbound' and 'passes' not in row['v2_projection']
  else:assert r['outcome']=='failed'
  results[scenario]=row
 finally:t.doCleanups()
(OUT/'extra-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
