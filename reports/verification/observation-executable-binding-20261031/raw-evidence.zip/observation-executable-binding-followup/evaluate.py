import importlib.util,json,pathlib,subprocess,hashlib
ROOT=pathlib.Path('/workspace/scratch/sdd-forge-main-integration');OUT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('fixture',ROOT/'tests/project-skill-lifecycle.tests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
t=m.Lifecycle();t.setUp();a=m.A
result={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_hashes':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['plugins/sdd-bootstrap/scripts/project-skill.py','plugins/sdd-quality-loop/scripts/validate-project-skill.py']}}
try:
 helper=t.skill/'helper.sh';helper.write_text("#!/bin/sh\nprintf 'helper ran\\n'\n");helper.chmod(0o755)
 t.seal('import subprocess\nsubprocess.run(["./sdd/skills/verify-app/helper.sh"],check=True)\n')
 task=t.task_manifest();before=t.run_skill(task_path=task);result['initial_run']=before
 obs=t.root/before['observation'];(OUT/'successful-observation.json').write_bytes(obs.read_bytes());(OUT/'task-input.json').write_bytes(task.read_bytes())
 oldhash=a.V.digest(helper.read_bytes());helper.chmod(0o644)
 result['helper_bytes_unchanged']=oldhash==a.V.digest(helper.read_bytes());result['after_mode']=oct(helper.stat().st_mode&0o777)
 try:
  validated=a.V.validate(t.root,'verify-app',obs,task)
  result['old_observation_validation']=validated[2]
  result['old_observation_projection']=a.V.project_execution({'id':'smoke','required':True},validated)
 except Exception as e:result['old_observation_rejected']=str(e)
 packet=json.loads(task.read_text());packet['run_id']='run2';packet['allowed_outputs']=['output/','reports/project-skill-observations/T-001/run2/'];task.write_text(json.dumps(packet))
 after=t.run_skill(task_path=task);result['fresh_run']=after
 result['fresh_stderr']=(t.root/after['stderr']['path']).read_text()
 (OUT/'fresh-observation.json').write_bytes((t.root/after['observation']).read_bytes())
finally:
 t.doCleanups();result['fixture_removed']=not t.root.exists();(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('initial_run','fresh_run')},indent=2))
print('runs',result['initial_run']['outcome'],result['fresh_run']['outcome'])
