from pathlib import Path
import subprocess,json,time,hashlib,sys
p=Path(__file__).resolve().parent
protocol=json.loads((p/'protocol.json').read_text());r=p/'source'
def source_hashes():
 return {str(f.relative_to(r)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(r.rglob('*')) if f.is_file() and not f.is_symlink()}
initial=source_hashes();(p/'source-hashes.json').write_text(json.dumps(initial,indent=2)+'\n')
results=[]
for n in (1,2):
 command=[sys.executable,'tests/verification.py','--suite',protocol['suite'],'--run','--measure-dir',str(p/f'measure-{n}'),'--receipt',str(p/f'receipt-{n}.json')]
 start=time.perf_counter()
 with (p/f'run-{n}.log').open('wb') as out:
  try:
   result=subprocess.run(command,cwd=r,env=protocol['environment'],stdout=out,stderr=subprocess.STDOUT,timeout=120)
   code=result.returncode;timeout=False
  except subprocess.TimeoutExpired:
   code=None;timeout=True
 elapsed=time.perf_counter()-start
 results.append({'trial':n,'command':command,'elapsed_seconds':elapsed,'exit_code':code,'timeout':timeout,'source_unchanged':source_hashes()==initial})
 (p/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if timeout:break
