This fixture contains selected sdd-forge repository source and its source-development coding standards. Proposed source change is in parse_output.py.
