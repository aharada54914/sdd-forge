import subprocess

def inspect_path(user_path):
    return subprocess.check_output("ls " + user_path, shell=True, text=True)
