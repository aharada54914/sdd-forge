Field notes: a documentation-only project. No coding standard or language tools are adopted. Proposed edit: change the support hours sentence from 9–5 to 10–6.
