# Collection layer: run Google Gemini panelist via gemini CLI in isolated scratch.
# Usage:
#   run-panelist-gemini.ps1 --task T-NNN --feature <f> --input <bundle-path>
#                           [--spec-root <dir>] [--model <model-id>]
#                           [--digest <64-hex>] [--consent <kind>]
#
# Writes verdict JSON to:
#   specs/<feature>/verification/T-NNN.panelist-google.verdict.json
#
# Graceful degrade: gemini CLI absent -> exit 1 (not exit 2; not a tool error).
# Panelist timeout: SDD_PANELIST_TIMEOUT whole seconds; expiry kills the process
# tree and exits 1 without writing a verdict.
# Key isolation: SDD_EVIDENCE_KEY / SDD_SUDO_KEY never passed to panelist.
#
# CLI contract: the installed `gemini` CLI only runs non-interactively via
# `-p/--prompt` ("Run in non-interactive (headless) mode with the given
# prompt. Appended to input on stdin (if any)."). A bare `gemini --model
# <m>` with piped stdin and no `-p` is not headless and can fail to produce
# a verdict (e.g. "No input provided via stdin..."). This script supplies
# the panelist instructions via `-p` and pipes the sanitized bundle on
# stdin, per the CLI's own documented contract.
#
# Exit codes: 0=success  1=CLI absent or panelist failure (CLI non-zero
#             exit, timeout, or output that does not parse into a valid
#             cross-model-verdict/v1 JSON object)  2=bad args. A run that
#             fails for any reason writes NO verdict file.
param()
$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot 'lib/native-arguments.ps1')

# Session selection delegates back to this unchanged collection path after binding.
if ($args -ccontains '--model-session') {
    $sessionOwner = Split-Path $PSScriptRoot -Parent
    $sessionVersion = Split-Path $sessionOwner -Leaf
    $sessionDriver = Join-Path $sessionOwner '../sdd-implementation/scripts/session-panelist.py'
    if ($sessionVersion -cne 'sdd-quality-loop') {
        $sessionDriver = Join-Path $sessionOwner "../../sdd-implementation/$sessionVersion/scripts/session-panelist.py"
    }
    if (-not (Test-Path -LiteralPath $sessionDriver -PathType Leaf) -or
        ((Get-Item -LiteralPath $sessionDriver).Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
        [Console]::Error.WriteLine('SESSION_MODEL_SELECTION_REQUIRED: matching plugin release is unavailable')
        exit 2
    }
    $sessionArgs = @($sessionDriver, '--vendor', 'gemini', '--shell', 'powershell',
        '--powershell', [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) + $args
    $sessionProcess = Start-Process -FilePath 'python3' -ArgumentList (ConvertTo-SddNativeArgumentString $sessionArgs) -NoNewWindow -PassThru -Wait
    exit $sessionProcess.ExitCode
}

# Selected-control runs are owned by the shared Python driver (validation, typed errors).
$selectedControlFlags = @("--model-controls", "--model-controls-sha256", "--run-id", "--session-id")
if (@($args | Where-Object { $selectedControlFlags -ccontains $_ }).Count -gt 0) {
    $selectedDriver = Join-Path $PSScriptRoot "../../sdd-review-loop/scripts/validate-nontty-spec-launch.py"
    # Start-Process uses the shared encoder on 5.1 as well as 7. The driver owns
    # the configured panelist timeout, so this adapter must not cap it again.
    $selectedArgs = @($selectedDriver, 'model-panelist-run', '--vendor', 'gemini', '--shell', 'powershell') + $args
    $selectedProcess = Start-Process -FilePath 'python3' -ArgumentList (ConvertTo-SddNativeArgumentString $selectedArgs) -NoNewWindow -PassThru -Wait
    exit $selectedProcess.ExitCode
}

$TaskId      = ""
$Feature     = ""
$InputPath   = ""
$SpecRoot    = "specs"
# Use the CLI/account configuration unless an explicit model is selected.
$Model       = ""
$InputDigest = ""
$ConsentKind = "human-flag"
$PanelistTimeoutDefault = 600

$argIdx = 0
$passedArgs = $args
while ($argIdx -lt $passedArgs.Count) {
    switch ($passedArgs[$argIdx]) {
        "--task"      { $TaskId      = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--feature"   { $Feature     = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--input"     { $InputPath   = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--spec-root" { $SpecRoot    = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--model"     { $Model       = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--digest"    { $InputDigest = $passedArgs[$argIdx+1]; $argIdx += 2 }
        "--consent"   { $ConsentKind = $passedArgs[$argIdx+1]; $argIdx += 2 }
        default {
            [Console]::Error.WriteLine("run-panelist-gemini: unknown argument: $($passedArgs[$argIdx])")
            exit 2
        }
    }
}

$panelistTimeoutRaw = $env:SDD_PANELIST_TIMEOUT
if ([string]::IsNullOrEmpty($panelistTimeoutRaw)) {
    $PanelistTimeout = $PanelistTimeoutDefault
} else {
    $parsedPanelistTimeout = 0
    if ($panelistTimeoutRaw -notmatch '^[0-9]+$' -or
        -not [int]::TryParse($panelistTimeoutRaw, [ref]$parsedPanelistTimeout) -or
        $parsedPanelistTimeout -le 0) {
        [Console]::Error.WriteLine("run-panelist-gemini: SDD_PANELIST_TIMEOUT must be a positive whole number of seconds (got: $panelistTimeoutRaw)")
        exit 2
    }
    $PanelistTimeout = $parsedPanelistTimeout
}

if (-not $TaskId)    { [Console]::Error.WriteLine("run-panelist-gemini: --task is required");    exit 2 }
if (-not $Feature)   { [Console]::Error.WriteLine("run-panelist-gemini: --feature is required"); exit 2 }
if (-not $InputPath) { [Console]::Error.WriteLine("run-panelist-gemini: --input is required");   exit 2 }
if (-not (Test-Path $InputPath)) {
    [Console]::Error.WriteLine("run-panelist-gemini: input file not found: $InputPath"); exit 1
}

# ── Check CLI availability ───────────────────────────────────────────────────
if (-not (Get-Command "gemini" -ErrorAction SilentlyContinue)) {
    [Console]::Error.WriteLine("run-panelist-gemini: gemini CLI not found in PATH — skipping Gemini panelist (graceful degrade)")
    exit 1
}

# ── Key isolation ────────────────────────────────────────────────────────────
$env:SDD_EVIDENCE_KEY  = $null
$env:SDD_SUDO_KEY      = $null
$env:SDD_SUDO_KEY_FILE = $null

$scratch = [System.IO.Path]::GetTempPath() + [System.IO.Path]::GetRandomFileName()
New-Item -ItemType Directory -Path $scratch -Force | Out-Null

try {
    $outDir  = Join-Path $SpecRoot (Join-Path $Feature "verification")
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    $outPath = Join-Path $outDir "$TaskId.panelist-google.verdict.json"

    $promptText = @'
You are an independent panelist reviewing a software implementation. You are
running BLIND: you have not seen any other panelist's verdict, the primary
evaluator's verdict, or any prior review feedback on this task.

Your role is READ-ONLY. You must not suggest, write, or edit code. You must
not approve or set any task status. Return a structured verdict JSON only.

## Input

The sanitized input bundle follows this message. Review it for correctness,
completeness, and adherence to the stated requirements and design.

## Output Format

Return ONLY a JSON object in this exact schema (no markdown, no prose):

{
  "schema": "cross-model-verdict/v1",
  "task_id": "<task_id>",
  "feature": "<feature>",
  "vendor": "google",
  "model": "<model>",
  "verdict": "PASS" or "NEEDS_WORK",
  "findings": [],
  "blind": true,
  "input_digest": "<digest-from-bundle-header>",
  "consent": { "kind": "<consent-kind>", "ref": "<ref>" }
}

Rules:
- verdict MUST be "PASS" or "NEEDS_WORK".
- findings MUST be an array (empty [] if none).
- blind MUST be true (boolean, not string).
- input_digest: copy the value from the "# input_digest:" comment in the bundle header.
- consent.kind: copy from the "# consent:" comment in the bundle header.
- Do not include any text outside the JSON object.
'@

    # The npm CLI commonly resolves to a .cmd shim on Windows. Its %*
    # forwarding cannot preserve multiline prompt arguments. Gemini appends
    # stdin to -p, so keep the non-interactive switch fixed and transport the
    # complete instructions and sanitized bundle in the redirected UTF-8 file.
    $cliPrompt = 'Review the complete instructions and sanitized input on stdin.'
    $bundleContent = Get-Content -Raw -Encoding Utf8 -LiteralPath $InputPath
    if ($Model) {
        $promptText += "`nThe explicit CLI model is $Model. Return that exact string in model; do not infer it from the bundle.`n"
    }
    $stdinContent = $promptText + "`n`n## Sanitized Input Bundle`n`n" + $bundleContent
    $stdinBundleFile = Join-Path $scratch "stdin-bundle.txt"
    [IO.File]::WriteAllText($stdinBundleFile, $stdinContent, [Text.UTF8Encoding]::new($false))

    $geminiArgs = @()
    if ($Model) { $geminiArgs += @("--model", $Model) }
    $geminiArgs += @("-p", $cliPrompt)
    $modelLabel = if ($Model) { $Model } else { "CLI default" }
    [Console]::Error.WriteLine("run-panelist-gemini: invoking gemini (model=$modelLabel task=$TaskId feature=$Feature)")

    $rawOutput = Join-Path $scratch "raw-output.txt"
    try {
        # Use one deadline for process launch and waiting. Besides keeping
        # startup inside the configured bound, the child-visible value lets
        # boundary tests target the runner's real timeout clock.
        $panelistDeadlineEpochMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + ([long]$PanelistTimeout * 1000)
        $hadDeadline = Test-Path Env:SDD_PANELIST_DEADLINE_EPOCH_MS
        $savedDeadline = $env:SDD_PANELIST_DEADLINE_EPOCH_MS
        $env:SDD_PANELIST_DEADLINE_EPOCH_MS = "$panelistDeadlineEpochMs"
        try {
            $proc = Start-Process -FilePath "gemini" `
                -ArgumentList (ConvertTo-SddNativeArgumentString $geminiArgs) `
                -RedirectStandardInput  $stdinBundleFile `
                -RedirectStandardOutput $rawOutput `
                -RedirectStandardError  (Join-Path $scratch "stderr.txt") `
                -PassThru -NoNewWindow
        } finally {
            if ($hadDeadline) { $env:SDD_PANELIST_DEADLINE_EPOCH_MS = $savedDeadline }
            else { Remove-Item Env:SDD_PANELIST_DEADLINE_EPOCH_MS -ErrorAction SilentlyContinue }
        }
        # WaitForExit takes Int32 milliseconds; clamp the remaining portion of
        # the absolute deadline so launch time cannot extend the timeout.
        $remainingMs = $panelistDeadlineEpochMs - [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        $panelistWaitMs = [int][Math]::Min([Math]::Max($remainingMs, 0), [int]::MaxValue)
        $waitCompleted = $proc.WaitForExit($panelistWaitMs)
        # Observe this exact handle, not the CLI worker's final output. A process
        # may exit between the timed wait and HasExited; retain both observations.
        $waitObservedAt = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        $observedExited = $proc.HasExited
        if (-not $waitCompleted -and -not $observedExited) {
            $proc.Kill($true)
            $proc.WaitForExit()
            # Logging follows cleanup so it cannot delay termination.
            [Console]::Error.WriteLine("panelist-process: pid=$($proc.Id) wait_completed=0 observed_at=$waitObservedAt observed_exited=$([int]$observedExited) cleanup_kill=1")
            [Console]::Error.WriteLine("run-panelist-gemini: gemini CLI exceeded SDD_PANELIST_TIMEOUT=${PanelistTimeout}s; terminated")
            exit 1
        }
        $proc.WaitForExit()
        [Console]::Error.WriteLine("panelist-process: pid=$($proc.Id) wait_completed=$([int]$waitCompleted) observed_at=$waitObservedAt observed_exited=$([int]$observedExited) cleanup_kill=0")
        if ($proc.ExitCode -ne 0) {
            [Console]::Error.WriteLine("run-panelist-gemini: gemini CLI exited $($proc.ExitCode)")
            Get-Content (Join-Path $scratch "stderr.txt") | ForEach-Object { [Console]::Error.WriteLine($_) }
            exit 1
        }
    } catch {
        [Console]::Error.WriteLine("run-panelist-gemini: failed to start gemini: $_")
        exit 1
    }

    $raw = Get-Content -Raw -Encoding Utf8 $rawOutput
    # Match the GPT runner's candidate selection: echoed objects are not
    # verdicts, and braces inside quoted strings do not delimit objects.
    $targetSchema = 'cross-model-verdict/v1'
    $cleanedOutputText = [regex]::Replace($raw, '```[ \t]*[A-Za-z0-9_-]*[ \t]*\r?\n|```', '')
    function Get-JsonObjectCandidates([string]$Text) {
        $candidates = [System.Collections.Generic.List[string]]::new()
        $i = 0
        while ($i -lt $Text.Length) {
            if ($Text[$i] -cne '{') { $i++; continue }
            $start = $i
            $depth = 0
            $inString = $false
            $escape = $false
            $closedAt = -1
            for ($j = $i; $j -lt $Text.Length; $j++) {
                $c = $Text[$j]
                if ($inString) {
                    if ($escape) { $escape = $false }
                    elseif ($c -ceq '\') { $escape = $true }
                    elseif ($c -ceq '"') { $inString = $false }
                } else {
                    if ($c -ceq '"') { $inString = $true }
                    elseif ($c -ceq '{') { $depth++ }
                    elseif ($c -ceq '}') {
                        $depth--
                        if ($depth -eq 0) { $closedAt = $j; break }
                    }
                }
            }
            if ($closedAt -ge 0) {
                $candidates.Add($Text.Substring($start, $closedAt - $start + 1))
                $i = $closedAt + 1
            } else {
                # A truncated echo must not hide later complete candidates.
                $i = $start + 1
            }
        }
        # Preserve a one-element list instead of unwrapping it to a string.
        Write-Output -NoEnumerate $candidates
    }
    $candidates = Get-JsonObjectCandidates $cleanedOutputText
    $verdict = $null
    $rejections = [System.Collections.Generic.List[string]]::new()
    for ($ci = 0; $ci -lt $candidates.Count; $ci++) {
        $candidateNum = $ci + 1
        try { $parsed = $candidates[$ci] | ConvertFrom-Json -ErrorAction Stop }
        catch {
            $rejections.Add("candidate ${candidateNum}: parse error: $($_.Exception.Message)")
            continue
        }
        if ($parsed -isnot [System.Management.Automation.PSCustomObject]) {
            $rejections.Add("candidate ${candidateNum}: parsed but is not a JSON object")
            continue
        }
        if ($parsed.schema -isnot [string] -or -not [string]::Equals($parsed.schema, $targetSchema, [StringComparison]::Ordinal)) {
            $rejections.Add("candidate ${candidateNum}: parsed but schema is '$($parsed.schema)' (expected '$targetSchema')")
            continue
        }
        $verdict = $parsed # The last schema-matching candidate wins.
    }
    if (-not $verdict) {
        if ($candidates.Count -eq 0) {
            [Console]::Error.WriteLine("run-panelist-gemini: no JSON object found in gemini output")
        } else {
            [Console]::Error.WriteLine("run-panelist-gemini: no $targetSchema verdict found among $($candidates.Count) candidate JSON object(s) in gemini output")
            foreach ($rejection in $rejections) { [Console]::Error.WriteLine("  $rejection") }
        }
        exit 1
    }

    if ($verdict.schema -isnot [string] -or $verdict.schema -cne "cross-model-verdict/v1") {
        [Console]::Error.WriteLine("run-panelist-gemini: wrong schema: $($verdict.schema)"); exit 1
    }
    if ($verdict.blind -isnot [bool] -or $verdict.blind -ne $true) {
        [Console]::Error.WriteLine("run-panelist-gemini: blind must be true"); exit 1
    }
    if ($verdict.input_digest -isnot [string] -or $verdict.input_digest -cnotmatch '^[0-9a-f]{64}$') {
        [Console]::Error.WriteLine("run-panelist-gemini: input_digest must be 64 lowercase hex"); exit 1
    }
    if ($verdict.verdict -isnot [string] -or $verdict.verdict -cnotin @("PASS","NEEDS_WORK")) {
        [Console]::Error.WriteLine("run-panelist-gemini: verdict must be PASS or NEEDS_WORK"); exit 1
    }

    if ($Model -and ($verdict.model -isnot [string] -or $verdict.model -cne $Model)) {
        [Console]::Error.WriteLine('run-panelist-gemini: returned model does not match explicit CLI model'); exit 1
    }
    $verdict.task_id = $TaskId
    $verdict.feature = $Feature
    $verdict.vendor  = "google"

    $verdict | ConvertTo-Json -Depth 10 | Set-Content -Encoding Utf8 -Path $outPath
    [Console]::Error.WriteLine("run-panelist-gemini: verdict written to $outPath")
    Write-Host $outPath

} finally {
    Remove-Item -Recurse -Force $scratch -ErrorAction SilentlyContinue
}

exit 0
